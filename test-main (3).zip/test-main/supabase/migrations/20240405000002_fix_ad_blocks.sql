-- Fix ad blocks to ensure they're properly configured

-- Make sure all ad blocks have the correct structure
UPDATE public.ai_models
SET 
  ad_type = 'banner',
  ad_position = CASE 
    WHEN id LIKE '%bottom%' THEN 'bottom'
    ELSE 'top'
  END,
  is_active = true,
  type = 'page',
  version = '1.0'
WHERE id IN (
  'dashboard-top-ad',
  'dashboard-bottom-ad',
  'chat-interface-top-ad',
  'chat-interface-bottom-ad',
  'image-generator-top-ad'
);

-- Ensure all ad blocks exist
INSERT INTO public.ai_models (id, name, description, type, version, is_active, ad_type, ad_position, ad_enabled, ad_code, ad_frequency, created_at)
VALUES 
('dashboard-top-ad', 'Dashboard Top', 'Ad placement for the top of dashboard page', 'page', '1.0', true, 'banner', 'top', false, '', 1, NOW()),
('dashboard-bottom-ad', 'Dashboard Bottom', 'Ad placement for the bottom of dashboard page', 'page', '1.0', true, 'banner', 'bottom', false, '', 1, NOW()),
('chat-interface-top-ad', 'Chat Interface Top', 'Ad placement for the top of chat interface', 'page', '1.0', true, 'banner', 'top', false, '', 1, NOW()),
('chat-interface-bottom-ad', 'Chat Interface Bottom', 'Ad placement for the bottom of chat interface', 'page', '1.0', true, 'banner', 'bottom', false, '', 1, NOW()),
('image-generator-top-ad', 'Image Generator Top', 'Ad placement for the top of image generator', 'page', '1.0', true, 'banner', 'top', false, '', 1, NOW())
ON CONFLICT (id) DO NOTHING;