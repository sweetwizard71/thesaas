-- Set admin status for techdungeon1@gmail.com
UPDATE public.users
SET is_admin = true
WHERE email = 'techdungeon1@gmail.com';
