-- Make sure ad settings columns exist first
ALTER TABLE ai_models
ADD COLUMN IF NOT EXISTS ad_type VARCHAR DEFAULT 'banner',
ADD COLUMN IF NOT EXISTS ad_code TEXT DEFAULT NULL,
ADD COLUMN IF NOT EXISTS ad_position VARCHAR DEFAULT 'top',
ADD COLUMN IF NOT EXISTS ad_frequency INTEGER DEFAULT 1,
ADD COLUMN IF NOT EXISTS ad_enabled BOOLEAN DEFAULT true;

-- Add page-specific ad placements for dashboard, chat, and images pages
INSERT INTO public.ai_models (id, name, description, type, version, is_active, ad_type, ad_position, ad_enabled, ad_code, ad_frequency, created_at)
VALUES 
('dashboard_page', 'Dashboard Page', 'Ad placement for the main dashboard page', 'page', '1.0', true, 'banner', 'top', false, NULL, 1, NOW()),
('chat_page', 'Chat Page', 'Ad placement for the chat interface page', 'page', '1.0', true, 'banner', 'top', false, NULL, 1, NOW()),
('images_page', 'Images Page', 'Ad placement for the image generation page', 'page', '1.0', true, 'banner', 'top', false, NULL, 1, NOW())
ON CONFLICT (id) DO UPDATE 
SET 
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  type = EXCLUDED.type,
  version = EXCLUDED.version,
  is_active = EXCLUDED.is_active,
  ad_type = EXCLUDED.ad_type,
  ad_position = EXCLUDED.ad_position,
  ad_enabled = EXCLUDED.ad_enabled,
  ad_code = EXCLUDED.ad_code,
  ad_frequency = EXCLUDED.ad_frequency;