-- Add ad settings columns to ai_models table
ALTER TABLE ai_models
ADD COLUMN IF NOT EXISTS ad_type VARCHAR DEFAULT 'banner',
ADD COLUMN IF NOT EXISTS ad_code TEXT DEFAULT NULL,
ADD COLUMN IF NOT EXISTS ad_position VARCHAR DEFAULT 'top',
ADD COLUMN IF NOT EXISTS ad_frequency INTEGER DEFAULT 1,
ADD COLUMN IF NOT EXISTS ad_enabled BOOLEAN DEFAULT true;

-- Update the publication for realtime
alter publication supabase_realtime add table ai_models;