-- Remove ad_frequency column from ai_models table if it exists
ALTER TABLE ai_models DROP COLUMN IF EXISTS ad_frequency;

-- Make sure we have unique entries for chat interface ads
DELETE FROM ai_models WHERE id = 'chat-top-ad';

-- Ensure we have both top and bottom ad blocks with unique values
INSERT INTO ai_models (id, name, type, version, is_active, ad_code, ad_enabled, description)
VALUES 
('chat-interface-top-ad', 'Chat Interface - Top', 'page', '1.0', true, '', false, 'Ad placement for Chat Interface - Top'),
('chat-interface-bottom-ad', 'Chat Interface - Bottom', 'page', '1.0', true, '', false, 'Ad placement for Chat Interface - Bottom')
ON CONFLICT (id) DO NOTHING;