-- Create ad_blocks table for managing ad placements
CREATE TABLE IF NOT EXISTS public.ad_blocks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    location VARCHAR NOT NULL UNIQUE,
    html_code TEXT,
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Add comment to table
COMMENT ON TABLE public.ad_blocks IS 'Stores ad code blocks for different locations on the site';

-- Create index on location for faster lookups
CREATE INDEX IF NOT EXISTS ad_blocks_location_idx ON public.ad_blocks (location);

-- Insert default header and footer blocks
INSERT INTO public.ad_blocks (location, html_code, active)
VALUES 
('header', '<!-- Header ad code goes here -->', true),
('footer', '<!-- Footer ad code goes here -->', true)
ON CONFLICT (location) DO NOTHING;

-- Enable row level security
ALTER TABLE public.ad_blocks ENABLE ROW LEVEL SECURITY;

-- Create policy for admins to manage ad blocks
DROP POLICY IF EXISTS "Admins can manage ad blocks" ON public.ad_blocks;
CREATE POLICY "Admins can manage ad blocks"
ON public.ad_blocks
USING (
    (SELECT is_admin FROM public.users WHERE id = auth.uid())
);

-- Create policy for all users to view ad blocks
DROP POLICY IF EXISTS "All users can view ad blocks" ON public.ad_blocks;
CREATE POLICY "All users can view ad blocks"
ON public.ad_blocks
FOR SELECT
USING (true);

-- Add to realtime publication
ALTER PUBLICATION supabase_realtime ADD TABLE public.ad_blocks;