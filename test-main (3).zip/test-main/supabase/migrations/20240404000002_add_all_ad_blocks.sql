-- Add all ad blocks to ensure they exist in the database
INSERT INTO public.ai_models (id, name, description, type, version, is_active, ad_type, ad_position, ad_enabled, ad_code, ad_frequency, created_at)
VALUES 
('dashboard-top-ad', 'Dashboard Top', 'Ad placement for the top of dashboard page', 'page', '1.0', true, 'banner', 'top', false, NULL, 1, NOW()),
('dashboard-bottom-ad', 'Dashboard Bottom', 'Ad placement for the bottom of dashboard page', 'page', '1.0', true, 'banner', 'bottom', false, NULL, 1, NOW()),
('chat-top-ad', 'Chat Page Top', 'Ad placement for the top of chat page', 'page', '1.0', true, 'banner', 'top', false, NULL, 1, NOW()),
('chat-bottom-ad', 'Chat Page Bottom', 'Ad placement for the bottom of chat page', 'page', '1.0', true, 'banner', 'bottom', false, NULL, 1, NOW()),
('chat-interface-top-ad', 'Chat Interface Top', 'Ad placement for the top of chat interface', 'page', '1.0', true, 'banner', 'top', false, NULL, 1, NOW()),
('chat-interface-bottom-ad', 'Chat Interface Bottom', 'Ad placement for the bottom of chat interface', 'page', '1.0', true, 'banner', 'bottom', false, NULL, 1, NOW()),
('images-top-ad', 'Images Page Top', 'Ad placement for the top of images page', 'page', '1.0', true, 'banner', 'top', false, NULL, 1, NOW()),
('images-bottom-ad', 'Images Page Bottom', 'Ad placement for the bottom of images page', 'page', '1.0', true, 'banner', 'bottom', false, NULL, 1, NOW()),
('image-generator-top-ad', 'Image Generator Top', 'Ad placement for the top of image generator', 'page', '1.0', true, 'banner', 'top', false, NULL, 1, NOW())
ON CONFLICT (id) DO UPDATE 
SET 
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  type = EXCLUDED.type,
  version = EXCLUDED.version,
  is_active = EXCLUDED.is_active;