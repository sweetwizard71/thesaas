-- Delete any entries with the old chat-top-ad ID to avoid conflicts
DELETE FROM ai_models WHERE id = 'chat-top-ad';

-- Ensure chat-interface-top-ad and chat-interface-bottom-ad have unique values
UPDATE ai_models 
SET name = 'Chat Interface - Top', 
    ad_code = COALESCE(ad_code, ''), 
    ad_frequency = COALESCE(ad_frequency, 1), 
    ad_enabled = COALESCE(ad_enabled, false)
WHERE id = 'chat-interface-top-ad';

UPDATE ai_models 
SET name = 'Chat Interface - Bottom', 
    ad_code = COALESCE(ad_code, ''), 
    ad_frequency = COALESCE(ad_frequency, 1), 
    ad_enabled = COALESCE(ad_enabled, false)
WHERE id = 'chat-interface-bottom-ad';
