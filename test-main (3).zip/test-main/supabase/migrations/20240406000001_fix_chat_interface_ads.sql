-- Delete any existing chat interface ad blocks to start fresh
DELETE FROM ai_models WHERE id IN ('chat-interface-top-ad', 'chat-interface-bottom-ad');

-- Insert fresh entries with different values
INSERT INTO ai_models (id, name, type, version, is_active, ad_code, ad_enabled, description)
VALUES 
('chat-interface-top-ad', 'Chat Interface - Top', 'page', '1.0', true, '', false, 'Ad placement for Chat Interface - Top'),
('chat-interface-bottom-ad', 'Chat Interface - Bottom', 'page', '1.0', true, '', false, 'Ad placement for Chat Interface - Bottom');
