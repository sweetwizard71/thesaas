-- Add additional ad placements for chat interface and image generator
INSERT INTO public.ai_models (id, name, description, type, version, is_active, ad_type, ad_position, ad_enabled, ad_code, ad_frequency, created_at)
VALUES 
('chat-interface-top-ad', 'Chat Interface Top', 'Ad placement for the top of chat interface', 'page', '1.0', true, 'banner', 'top', false, NULL, 1, NOW()),
('chat-interface-bottom-ad', 'Chat Interface Bottom', 'Ad placement for the bottom of chat interface', 'page', '1.0', true, 'banner', 'bottom', false, NULL, 1, NOW()),
('image-generator-top-ad', 'Image Generator Top', 'Ad placement for the top of image generator', 'page', '1.0', true, 'banner', 'top', false, NULL, 1, NOW())
ON CONFLICT (id) DO UPDATE 
SET 
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  type = EXCLUDED.type,
  version = EXCLUDED.version,
  is_active = EXCLUDED.is_active,
  ad_type = EXCLUDED.ad_type,
  ad_position = EXCLUDED.ad_position,
  ad_enabled = EXCLUDED.ad_enabled,
  ad_code = EXCLUDED.ad_code,
  ad_frequency = EXCLUDED.ad_frequency;