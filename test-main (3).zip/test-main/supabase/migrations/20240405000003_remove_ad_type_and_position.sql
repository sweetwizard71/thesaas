-- Remove ad_type and ad_position columns from ai_models table
ALTER TABLE ai_models
DROP COLUMN IF EXISTS ad_type,
DROP COLUMN IF EXISTS ad_position;
