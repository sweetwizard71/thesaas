-- Add header_code and footer_code columns to ai_models table if they don't exist
-- These columns are non-breaking and optional enhancements for ad display
-- They allow for storing custom HTML/JS code per model for header and footer ad placements
-- This provides flexibility in ad management without hardcoding ad logic

DO $$ 
BEGIN
  IF NOT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_name='ai_models' AND column_name='header_code') THEN
    ALTER TABLE ai_models ADD COLUMN header_code TEXT;
  END IF;
  
  IF NOT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_name='ai_models' AND column_name='footer_code') THEN
    ALTER TABLE ai_models ADD COLUMN footer_code TEXT;
  END IF;
END $$;