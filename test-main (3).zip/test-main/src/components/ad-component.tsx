"use client";

import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { LoadingSpinner } from "@/components/ui/loading-spinner";

export interface AdSettings {
  adCode?: string;
  isEnabled?: boolean;
}

interface AdComponentProps {
  settings: AdSettings;
  className?: string;
  onAdLoaded?: () => void;
  onAdError?: (error: string) => void;
}

export function AdComponent({
  settings,
  className,
  onAdLoaded,
  onAdError,
  id,
}: AdComponentProps & { id?: string }) {
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Simulate ad loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
      onAdLoaded?.();
    }, 1000);

    return () => clearTimeout(timer);
  }, [onAdLoaded, settings.adCode]);

  // Handle ad content
  const renderAdContent = () => {
    if (isLoading) {
      return <LoadingSpinner size="sm" text="Loading advertisement..." />;
    }

    if (error) {
      return <p className="text-sm text-muted-foreground">Ad failed to load</p>;
    }

    // If there's a custom ad code and ads are enabled, render it
    if (settings.adCode && settings.isEnabled) {
      return (
        <div
          dangerouslySetInnerHTML={{ __html: settings.adCode }}
          className="w-full h-full"
        />
      );
    }

    // If ads are disabled, return null for a clean look
    if (!settings.isEnabled) {
      return null;
    }

    // Default placeholder when no ad code is provided
    return (
      <div className="bg-muted/30 p-2 text-center rounded">
        <p className="text-sm font-medium">Advertisement</p>
        <div className="bg-muted h-16 flex items-center justify-center">
          <p className="text-xs text-muted-foreground">Ad Placeholder</p>
        </div>
      </div>
    );
  };

  return (
    <Card className={className} id={id}>
      <CardContent className="p-2">{renderAdContent()}</CardContent>
    </Card>
  );
}
