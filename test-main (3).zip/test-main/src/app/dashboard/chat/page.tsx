import { redirect } from "next/navigation";
import { createClient } from "../../../../supabase/server";
import DashboardNavbar from "@/components/dashboard-navbar";
import { InfoIcon } from "lucide-react";
import ChatInterface from "./chat-interface";
import { AdComponent } from "@/components/ad-component";

export default async function ChatPage() {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return redirect("/sign-in");
  }

  // Fetch ad settings for chat interface from database
  // Use chat-interface-top-ad ID to avoid confusion with chat-top-ad
  const { data: chatInterfaceTopAd } = await supabase
    .from("ai_models")
    .select("*")
    .eq("id", "chat-interface-top-ad")
    .single();

  const { data: chatInterfaceBottomAd } = await supabase
    .from("ai_models")
    .select("*")
    .eq("id", "chat-interface-bottom-ad")
    .single();

  // Default ad settings if none found
  const topAdSettings = {
    adCode: chatInterfaceTopAd?.ad_code || "",
    isEnabled: chatInterfaceTopAd?.ad_enabled || false,
  };

  const bottomAdSettings = {
    adCode: chatInterfaceBottomAd?.ad_code || "",
    isEnabled: chatInterfaceBottomAd?.ad_enabled || false,
  };

  return (
    <>
      <DashboardNavbar />
      <main className="w-full">
        <div className="container mx-auto px-4 py-8 flex flex-col gap-8">
          {/* Header Section */}
          <header className="flex flex-col gap-4">
            <h1 className="text-3xl font-bold">AI Chat</h1>
            <div className="bg-secondary/50 text-sm p-3 px-4 rounded-lg text-muted-foreground flex gap-2 items-center">
              <InfoIcon size="14" />
              <span>Chat with AI models powered by Replicate API</span>
            </div>
          </header>

          {/* Ad Block - Top Position */}
          {topAdSettings.isEnabled && (
            <div id="chat-interface-top-ad" className="w-full mb-6">
              <AdComponent
                settings={topAdSettings}
                className="w-full"
                id="chat-interface-top-ad-component"
              />
            </div>
          )}

          {/* Chat Interface */}
          <ChatInterface />

          {/* Ad Block - Bottom Position */}
          {bottomAdSettings.isEnabled && (
            <div id="chat-interface-bottom-ad" className="w-full mt-6">
              <AdComponent
                settings={bottomAdSettings}
                className="w-full"
                id="chat-interface-bottom-ad-component"
              />
            </div>
          )}
        </div>
      </main>
    </>
  );
}
