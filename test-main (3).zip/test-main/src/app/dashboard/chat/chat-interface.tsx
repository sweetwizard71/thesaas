"use client";

import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { chatModels, refreshModels } from "@/lib/replicate";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { AdComponent } from "@/components/ad-component";

type Message = {
  role: "user" | "assistant";
  content: string;
};

type Chat = {
  id: string;
  title: string;
  messages: Message[];
  createdAt: number;
};

export default function ChatInterface() {
  const [chats, setChats] = useState<Chat[]>([]);
  const [activeChat, setActiveChat] = useState<string>("");
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: "Hello! How can I help you today?" },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [model, setModel] = useState("");
  const [temperature, setTemperature] = useState("0.7");
  const [showSidebar, setShowSidebar] = useState(true);
  // Ad settings are managed in the admin panel - we'll fetch them when needed
  const [topAdSettings, setTopAdSettings] = useState({
    adType: "banner",
    adCode: "",
    adPosition: "top",
    isEnabled: false, // Disable ads by default until properly fetched
  });
  const [bottomAdSettings, setBottomAdSettings] = useState({
    adType: "banner",
    adCode: "",
    adPosition: "bottom",
    isEnabled: false, // Disable ads by default until properly fetched
  });
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Generate a title from the first user message
  const generateChatTitle = (message: string): string => {
    // Truncate to first 30 chars or first sentence
    const title = message.split(".")[0].trim().substring(0, 30);
    return title.length < message.length ? `${title}...` : title;
  };

  // Create a new chat
  const createNewChat = () => {
    const newChat: Chat = {
      id: Date.now().toString(),
      title: "New Chat",
      messages: [
        { role: "assistant", content: "Hello! How can I help you today?" },
      ],
      createdAt: Date.now(),
    };

    setChats((prev) => [newChat, ...prev]);
    setActiveChat(newChat.id);
    setMessages(newChat.messages);
    setInput("");
  };

  // Delete a chat
  const deleteChat = (chatId: string) => {
    setChats((prev) => prev.filter((chat) => chat.id !== chatId));

    // If the active chat was deleted, set the first available chat as active or create a new one
    if (activeChat === chatId) {
      const remainingChats = chats.filter((chat) => chat.id !== chatId);
      if (remainingChats.length > 0) {
        setActiveChat(remainingChats[0].id);
        setMessages(remainingChats[0].messages);
      } else {
        createNewChat();
      }
    }
  };

  // Switch to a different chat
  const switchChat = (chatId: string) => {
    const chat = chats.find((c) => c.id === chatId);
    if (chat) {
      setActiveChat(chatId);
      setMessages(
        chat.messages || [
          { role: "assistant", content: "Hello! How can I help you today?" },
        ],
      );
    }
  };

  // Load models, ad settings, and chat history on component mount
  useEffect(() => {
    // Refresh models from database
    refreshModels().then(() => {
      // Set default model after models are refreshed
      if (chatModels.length > 0 && !model) {
        setModel(chatModels[0].id);
      }
    });

    // Fetch ad settings from database
    const fetchAdSettings = async () => {
      try {
        const response = await fetch("/api/admin/models");
        if (response.ok) {
          const data = await response.json();
          const topAd = data.models.find(
            (m: any) => m.id === "chat-interface-top-ad",
          );
          const bottomAd = data.models.find(
            (m: any) => m.id === "chat-interface-bottom-ad",
          );

          if (topAd) {
            setTopAdSettings({
              adType: topAd.ad_type || "banner",
              adCode: topAd.ad_code || "",
              adPosition: "top",
              isEnabled: topAd.ad_enabled || false,
            });
          }

          if (bottomAd) {
            setBottomAdSettings({
              adType: bottomAd.ad_type || "banner",
              adCode: bottomAd.ad_code || "",
              adPosition: "bottom",
              isEnabled: bottomAd.ad_enabled || false,
            });
          }
        }
      } catch (error) {
        console.error("Error fetching ad settings:", error);
      }
    };

    fetchAdSettings();

    try {
      const savedChats = localStorage.getItem("chatHistory");
      if (savedChats) {
        try {
          const parsedChats = JSON.parse(savedChats) as Chat[];

          // Filter out any invalid chats
          const validChats = parsedChats.filter(
            (chat) =>
              chat &&
              chat.id &&
              typeof chat.id === "string" &&
              Array.isArray(chat.messages),
          );

          setChats(validChats);

          // Set the most recent chat as active if available
          if (validChats.length > 0) {
            const mostRecentChat = validChats[0];
            setActiveChat(mostRecentChat.id);
            setMessages(
              mostRecentChat.messages || [
                {
                  role: "assistant",
                  content: "Hello! How can I help you today?",
                },
              ],
            );
          } else {
            createNewChat();
          }
        } catch (e) {
          console.error("Failed to parse saved chats", e);
          localStorage.removeItem("chatHistory");
          createNewChat();
        }
      } else {
        createNewChat();
      }
    } catch (error) {
      console.error("Error loading chat history:", error);
      createNewChat();
    }
  }, []);

  // Save chat history to localStorage
  useEffect(() => {
    if (chats.length > 0 && activeChat) {
      try {
        // Update the messages of the active chat without triggering a state update
        const updatedChats = chats.map((chat) =>
          chat.id === activeChat ? { ...chat, messages } : chat,
        );

        // Only save to localStorage without updating state
        localStorage.setItem("chatHistory", JSON.stringify(updatedChats));
      } catch (error) {
        console.error("Error saving chat history:", error);
      }
    }
  }, [messages, activeChat, chats]);

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    // Ensure we have a valid model selected
    if (!model || !chatModels.some((m) => m.id === model)) {
      // If current model is invalid, select the first available model
      if (chatModels.length > 0) {
        setModel(chatModels[0].id);
      } else {
        setMessages((prev) => [
          ...prev,
          {
            role: "assistant",
            content: "Error: No chat models available. Please try again later.",
          },
        ]);
        return;
      }
    }

    // Add user message
    const userMessage = { role: "user" as const, content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    // If this is the first user message in a "New Chat", update the chat title
    if (
      activeChat &&
      chats.find((c) => c.id === activeChat)?.title === "New Chat" &&
      messages.length === 1
    ) {
      // Store the title to update after the message is sent
      const newTitle = generateChatTitle(input);

      // We'll update the chat title after the API call completes
      setTimeout(() => {
        setChats((prevChats) =>
          prevChats.map((chat) =>
            chat.id === activeChat ? { ...chat, title: newTitle } : chat,
          ),
        );
      }, 0);
    }

    try {
      // Find the model version from the chatModels array
      const selectedModel = chatModels.find((m) => m.id === model);
      if (!selectedModel) {
        throw new Error(`Model ${model} not found`);
      }

      // Prepare conversation history for the API
      // We'll send the last 10 messages to avoid token limits
      const conversationHistory = messages.slice(-10).map((msg) => ({
        role: msg.role,
        content: msg.content,
      }));

      const response = await fetch("/api/replicate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          type: "chat",
          prompt: input,
          modelId: selectedModel.id,
          temperature: temperature,
          history: conversationHistory,
        }),
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();

      if (data.error) {
        throw new Error(`API error: ${data.error}`);
      }

      // Add assistant message
      const responseText =
        data.response || "Sorry, I couldn't generate a response.";
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: responseText },
      ]);
    } catch (error) {
      console.error("Error sending message:", error);
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "Sorry, there was an error processing your request.",
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const clearChat = () => {
    // Clear only the current active chat
    const clearedMessages = [
      { role: "assistant", content: "Hello! How can I help you today?" },
    ];
    setMessages(clearedMessages);

    // Update the chat in the list in the next tick to avoid state update conflicts
    setTimeout(() => {
      setChats((prevChats) =>
        prevChats.map((chat) =>
          chat.id === activeChat
            ? { ...chat, messages: clearedMessages, title: "New Chat" }
            : chat,
        ),
      );
    }, 0);
  };

  const clearAllChats = () => {
    createNewChat();
    setChats([]);
    localStorage.removeItem("chatHistory");
  };

  return (
    <div className="flex h-[calc(100vh-12rem)]">
      {/* Chat Sidebar */}
      <div
        className={`${showSidebar ? "w-64" : "w-0"} transition-all duration-300 overflow-hidden border-r`}
      >
        <div className="p-4 h-full flex flex-col">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-semibold">Chat History</h3>
            <Button variant="ghost" size="sm" onClick={createNewChat}>
              New Chat
            </Button>
          </div>

          <div className="flex-grow overflow-y-auto space-y-2 mb-4">
            {chats.map((chat) => (
              <div
                key={chat.id}
                className={`p-2 rounded-md cursor-pointer flex justify-between items-center group ${activeChat === chat.id ? "bg-primary/10" : "hover:bg-muted/50"}`}
                onClick={() => switchChat(chat.id)}
              >
                <span className="text-sm truncate flex-grow">{chat.title}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  className="opacity-0 group-hover:opacity-100 h-6 w-6 p-0"
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteChat(chat.id);
                  }}
                >
                  ×
                </Button>
              </div>
            ))}
          </div>

          <div className="space-y-2 pt-4 border-t">
            <Button
              variant="outline"
              size="sm"
              className="w-full"
              onClick={clearAllChats}
            >
              Clear All Chats
            </Button>
          </div>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-grow flex flex-col">
        {/* Chat Header */}
        <div className="p-4 border-b flex justify-between items-center">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowSidebar(!showSidebar)}
          >
            ☰
          </Button>
          <h2 className="font-semibold text-lg">
            {activeChat && chats.length > 0
              ? chats.find((c) => c.id === activeChat)?.title || "Chat"
              : "Chat"}
          </h2>
          <div className="space-x-2">
            <Button variant="ghost" size="sm" onClick={clearChat}>
              Clear Chat
            </Button>
            <Button variant="ghost" size="sm" onClick={createNewChat}>
              New Chat
            </Button>
          </div>
        </div>

        {/* Ad Block - Chat Interface Top */}
        {topAdSettings.isEnabled && (
          <div id="chat-interface-top-ad" className="w-full mb-4">
            <AdComponent
              settings={topAdSettings}
              className="w-full"
              id="chat-interface-top-ad-component"
            />
          </div>
        )}

        {/* Messages Area */}
        <div className="flex-grow overflow-y-auto p-4 bg-muted/30">
          <div className="space-y-4 max-w-3xl mx-auto">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex ${message.role === "assistant" ? "justify-start" : "justify-end"}`}
              >
                <div
                  className={`${message.role === "assistant" ? "bg-background" : "bg-primary/10"} p-3 rounded-lg max-w-[80%]`}
                >
                  <p className="text-sm font-medium mb-1">
                    {message.role === "assistant" ? "AI Assistant" : "You"}
                  </p>
                  <p className="whitespace-pre-wrap">{message.content}</p>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-background p-3 rounded-lg max-w-[80%]">
                  <p className="text-sm font-medium mb-1">AI Assistant</p>
                  <LoadingSpinner size="sm" text="Thinking..." />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Ad Block - Chat Interface Bottom */}
        {bottomAdSettings.isEnabled && (
          <div id="chat-interface-bottom-ad" className="w-full mb-4">
            <AdComponent
              settings={bottomAdSettings}
              className="w-full"
              id="chat-interface-bottom-ad-component"
            />
          </div>
        )}

        {/* Input Area */}
        <div className="p-4 border-t">
          <div className="max-w-3xl mx-auto flex gap-2">
            <Textarea
              placeholder="Type your message here..."
              className="resize-none"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={isLoading}
              rows={1}
            />
            <Button
              className="self-end"
              onClick={handleSendMessage}
              disabled={isLoading || !input.trim()}
            >
              {isLoading ? "Sending..." : "Send"}
            </Button>
          </div>
        </div>
      </div>

      {/* Settings Panel */}
      <div className="w-64 border-l p-4 hidden lg:block">
        <h3 className="font-semibold mb-4">Settings</h3>
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Select Model</label>
            <Select value={model} onValueChange={setModel}>
              <SelectTrigger>
                <SelectValue placeholder="Select a model" />
              </SelectTrigger>
              <SelectContent>
                {chatModels.map((model) => (
                  <SelectItem key={model.id} value={model.id}>
                    {model.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Temperature</label>
            <Select value={temperature} onValueChange={setTemperature}>
              <SelectTrigger>
                <SelectValue placeholder="Select temperature" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="0.3">0.3 - More focused</SelectItem>
                <SelectItem value="0.7">0.7 - Balanced</SelectItem>
                <SelectItem value="1.0">1.0 - More creative</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
    </div>
  );
}
