import DashboardNavbar from "@/components/dashboard-navbar";
import { InfoIcon, MessageSquare, Image, Settings } from "lucide-react";
import { redirect } from "next/navigation";
import { createClient } from "../../../supabase/server";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { AdComponent } from "@/components/ad-component";

export default async function Dashboard() {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return redirect("/sign-in");
  }

  // Check if user is admin
  const { data: userRole } = await supabase
    .from("users")
    .select("role")
    .eq("id", user.id)
    .single();

  const isAdmin = userRole?.role === "admin";

  // Fetch ad settings for dashboard page
  const { data: dashboardTopAd } = await supabase
    .from("ai_models")
    .select("*")
    .eq("id", "dashboard-top-ad")
    .single();

  const { data: dashboardBottomAd } = await supabase
    .from("ai_models")
    .select("*")
    .eq("id", "dashboard-bottom-ad")
    .single();

  // Default ad settings if none found
  const topAdSettings = {
    adCode: dashboardTopAd?.ad_code || "",
    isEnabled: dashboardTopAd?.ad_enabled || false,
  };

  const bottomAdSettings = {
    adCode: dashboardBottomAd?.ad_code || "",
    isEnabled: dashboardBottomAd?.ad_enabled || false,
  };

  return (
    <>
      <DashboardNavbar />
      <main className="w-full bg-gradient-to-b from-background to-background/60 min-h-screen">
        <div className="container mx-auto px-4 py-8 flex flex-col gap-8">
          {/* Ad Blocks with specific IDs */}
          {topAdSettings.isEnabled && (
            <div id="dashboard-top-ad" className="w-full mb-6">
              <AdComponent
                settings={topAdSettings}
                className="w-full"
                id="dashboard-top-ad-component"
              />
            </div>
          )}

          {/* Header Section */}
          <header className="flex flex-col gap-4 animate-fade-in">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Welcome to Your Dashboard
            </h1>
            <div className="bg-secondary/50 text-sm p-4 px-5 rounded-xl text-muted-foreground flex gap-3 items-center border border-border/40 shadow-sm">
              <InfoIcon size="16" className="text-primary" />
              <span>
                This is a protected page only visible to authenticated users
              </span>
            </div>
          </header>

          {/* Features Section */}
          <section className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-slide-up">
            <div className="bg-card rounded-xl p-6 border border-border/40 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
              <div className="flex items-center gap-3 mb-3">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <MessageSquare size="20" className="text-primary" />
                </div>
                <h3 className="font-semibold text-lg">AI Chat</h3>
              </div>
              <p className="text-muted-foreground mb-4">
                Chat with various AI models powered by Replicate API
              </p>
              <div className="flex flex-col gap-2">
                <p className="text-xs text-muted-foreground">
                  Available models: Llama 3, Mistral 7B
                </p>
                <Link href="/dashboard/chat" className="mt-2">
                  <Button variant="gradient" className="w-full">
                    Start Chatting
                  </Button>
                </Link>
              </div>
            </div>
            <div className="bg-card rounded-xl p-6 border border-border/40 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
              <div className="flex items-center gap-3 mb-3">
                <div className="p-2 bg-accent/10 rounded-lg">
                  <Image size="20" className="text-accent" />
                </div>
                <h3 className="font-semibold text-lg">Image Generation</h3>
              </div>
              <p className="text-muted-foreground mb-4">
                Generate images using AI models powered by Replicate API
              </p>
              <div className="flex flex-col gap-2">
                <p className="text-xs text-muted-foreground">
                  Available models: Stable Diffusion XL, Stable Diffusion 2
                </p>
                <Link href="/dashboard/images" className="mt-2">
                  <Button variant="gradient" className="w-full">
                    Generate Images
                  </Button>
                </Link>
              </div>
            </div>
            {isAdmin && (
              <div className="bg-card rounded-xl p-6 border border-border/40 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                <div className="flex items-center gap-3 mb-3">
                  <div className="p-2 bg-destructive/10 rounded-lg">
                    <Settings size="20" className="text-destructive" />
                  </div>
                  <h3 className="font-semibold text-lg">Admin Panel</h3>
                </div>
                <p className="text-muted-foreground mb-4">
                  Manage AI models and configure platform settings
                </p>
                <div className="flex flex-col gap-2">
                  <p className="text-xs text-muted-foreground">
                    Add, edit, or remove AI models for chat and image generation
                  </p>
                  <Link href="/dashboard/admin" className="mt-2">
                    <Button
                      variant="outline"
                      className="w-full border-destructive/30 text-destructive hover:bg-destructive/10"
                    >
                      Access Admin
                    </Button>
                  </Link>
                </div>
              </div>
            )}
          </section>

          {/* Ad Block - Bottom Position */}
          {bottomAdSettings.isEnabled && (
            <div id="dashboard-bottom-ad" className="w-full mt-6">
              <AdComponent
                settings={bottomAdSettings}
                className="w-full"
                id="dashboard-bottom-ad-component"
              />
            </div>
          )}
        </div>
      </main>
    </>
  );
}
