"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { RefreshCw } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

type AdBlock = {
  id: string;
  location: string;
  html_code: string;
  active: boolean;
  updated_at?: string;
};

export default function AdBlocksPanel() {
  const [adBlocks, setAdBlocks] = useState<AdBlock[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [saveStatus, setSaveStatus] = useState<Record<string, boolean>>({});

  // Set document title - removed to avoid client/server mismatch

  // Fetch ad blocks
  const fetchAdBlocks = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/admin/ad-blocks");
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();
      setAdBlocks(data.adBlocks || []);
    } catch (err: any) {
      console.error("Error fetching ad blocks:", err);
      setError(err.message || "Failed to fetch ad blocks");
    } finally {
      setLoading(false);
    }
  };

  // Load ad blocks on component mount
  useEffect(() => {
    fetchAdBlocks();
  }, []);

  // Handle HTML code changes
  const handleHtmlCodeChange = (id: string, value: string) => {
    setAdBlocks((prev) =>
      prev.map((block) =>
        block.id === id ? { ...block, html_code: value } : block,
      ),
    );
    setSaveStatus((prev) => ({ ...prev, [id]: false }));
  };

  // Handle active state changes
  const handleActiveChange = (id: string, checked: boolean) => {
    setAdBlocks((prev) =>
      prev.map((block) =>
        block.id === id ? { ...block, active: checked } : block,
      ),
    );
    setSaveStatus((prev) => ({ ...prev, [id]: false }));
  };

  // Save ad block
  const saveAdBlock = async (id: string) => {
    try {
      const adBlock = adBlocks.find((block) => block.id === id);
      if (!adBlock) return;

      const response = await fetch("/api/admin/ad-blocks", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(adBlock),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `API error: ${response.status}`);
      }

      setSaveStatus((prev) => ({ ...prev, [id]: true }));
      setTimeout(() => {
        setSaveStatus((prev) => ({ ...prev, [id]: false }));
      }, 3000);
    } catch (err: any) {
      console.error("Error saving ad block:", err);
      setError(err.message || "Failed to save ad block");
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">
            Website Code Management
          </h2>
          <p className="text-muted-foreground mt-1">
            Manage custom code that will be injected into your website's header
            and footer.
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={fetchAdBlocks}
          disabled={loading}
        >
          <RefreshCw
            className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`}
          />
          Refresh
        </Button>
      </div>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
          {error}
          <Button
            variant="ghost"
            size="sm"
            className="absolute top-0 right-0 mt-1 mr-1"
            onClick={() => setError(null)}
          >
            ×
          </Button>
        </div>
      )}

      {loading ? (
        <div className="flex justify-center items-center h-40">
          <RefreshCw className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : adBlocks.length === 0 ? (
        <div className="text-center py-10 text-muted-foreground">
          No ad blocks found. Please check your database configuration.
        </div>
      ) : (
        <div className="grid gap-6">
          {adBlocks.map((adBlock) => (
            <Card key={adBlock.id}>
              <CardHeader className="pb-3">
                <CardTitle className="capitalize flex items-center text-lg">
                  <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary mr-2">
                    {adBlock.location === "header" ? "H" : "F"}
                  </span>
                  {adBlock.location === "header" ? "Header" : "Footer"} Code
                  Block
                </CardTitle>
                <CardDescription>
                  HTML/JavaScript code that will be injected into the{" "}
                  {adBlock.location} of your website. Use this for analytics,
                  tracking, or custom scripts.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <Label
                      htmlFor={`html_code_${adBlock.id}`}
                      className="font-medium"
                    >
                      HTML/JavaScript Code
                    </Label>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id={`active_${adBlock.id}`}
                        checked={adBlock.active}
                        onCheckedChange={(checked) =>
                          handleActiveChange(adBlock.id, checked)
                        }
                      />
                      <Label
                        htmlFor={`active_${adBlock.id}`}
                        className="text-sm"
                      >
                        {adBlock.active ? "Active" : "Inactive"}
                      </Label>
                    </div>
                  </div>
                  <div className="relative">
                    <Textarea
                      id={`html_code_${adBlock.id}`}
                      placeholder={
                        adBlock.location === "header"
                          ? "<!-- Add your header code here (meta tags, analytics, etc.) -->"
                          : "<!-- Add your footer code here (scripts, tracking code, etc.) -->"
                      }
                      className="font-mono text-sm h-40 border-dashed"
                      value={adBlock.html_code || ""}
                      onChange={(e) =>
                        handleHtmlCodeChange(adBlock.id, e.target.value)
                      }
                    />
                    <div className="absolute top-2 right-2 text-xs px-2 py-1 bg-muted rounded-md text-muted-foreground">
                      {adBlock.location === "header" ? "<head>" : "</body>"}
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    This code will be injected into the{" "}
                    <span className="font-mono bg-primary/10 text-primary px-1 rounded">
                      {adBlock.location === "header"
                        ? "&lt;head&gt;"
                        : "before &lt;/body&gt;"}
                    </span>{" "}
                    section of your website.
                  </p>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between pt-2 border-t">
                <p className="text-sm text-muted-foreground flex items-center">
                  {saveStatus[adBlock.id] && (
                    <span className="text-green-600 flex items-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="mr-1"
                      >
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                        <polyline points="22 4 12 14.01 9 11.01"></polyline>
                      </svg>
                      Changes saved successfully
                    </span>
                  )}
                </p>
                <Button
                  onClick={() => saveAdBlock(adBlock.id)}
                  className="px-4"
                >
                  Save Changes
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
