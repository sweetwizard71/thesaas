"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { PlusCircle, Pencil, Trash2, RefreshCw } from "lucide-react";

type AdPlacement = {
  id: string;
  name: string;
  ad_code: string;
  header_code?: string;
  footer_code?: string;
  ad_enabled: boolean;
};

export default function AdminAdManagement() {
  const [adPlacements, setAdPlacements] = useState<AdPlacement[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [currentPlacement, setCurrentPlacement] = useState<AdPlacement | null>(
    null,
  );

  // Form state
  const [formData, setFormData] = useState<{
    id: string;
    name: string;
    ad_code: string;
    header_code: string;
    footer_code: string;
    ad_enabled: boolean;
  }>({
    id: "",
    name: "",
    ad_code: "",
    header_code: "",
    footer_code: "",
    ad_enabled: true,
  });

  // Fetch ad placements
  const fetchAdPlacements = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/admin/models");
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();
      // Filter models to include only active page placements and model placements with ad settings
      const placementsData = data.models
        .filter(
          (model: any) =>
            // Include only active placements
            model.is_active === true &&
            // Include page type placements
            (model.type === "page" ||
              // Include models with ad settings
              model.ad_type ||
              model.ad_code ||
              model.ad_position),
        )
        .map((model: any) => ({
          id: model.id,
          name: model.name,
          ad_code: model.ad_code || "",
          ad_enabled: model.ad_enabled || false,
        }));

      // Core ad blocks for main page sections
      const additionalAdBlocks = [
        {
          id: "dashboard-top-ad",
          name: "Dashboard - Top",
          ad_code: "",
          ad_enabled: false,
        },
        {
          id: "dashboard-bottom-ad",
          name: "Dashboard - Bottom",
          ad_code: "",
          ad_enabled: false,
        },
        {
          id: "chat-interface-top-ad",
          name: "Chat Interface - Top",
          ad_code: "",
          ad_enabled: false,
        },
        {
          id: "chat-interface-bottom-ad",
          name: "Chat Interface - Bottom",
          ad_code: "",
          ad_enabled: false,
        },
        {
          id: "image-generator-top-ad",
          name: "Image Generator - Top",
          ad_code: "",
          ad_enabled: false,
        },
      ];

      // Add only blocks that don't already exist in the data
      const existingIds = placementsData.map((p) => p.id);
      const newBlocks = additionalAdBlocks.filter(
        (block) => !existingIds.includes(block.id),
      );

      // Sort placements alphabetically by name
      const sortedPlacements = [...placementsData, ...newBlocks].sort(
        (a, b) => {
          return a.name.localeCompare(b.name);
        },
      );

      setAdPlacements(sortedPlacements);
    } catch (err: any) {
      console.error("Error fetching ad placements:", err);
      setError(err.message || "Failed to fetch ad placements");
    } finally {
      setLoading(false);
    }
  };

  // Load ad placements on component mount
  useEffect(() => {
    fetchAdPlacements();
  }, []);

  // Handle form input changes
  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Handle select changes
  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Handle switch changes
  const handleSwitchChange = (name: string, checked: boolean) => {
    setFormData((prev) => ({ ...prev, [name]: checked }));
  };

  // Handle number input changes
  const handleNumberChange = (name: string, value: string) => {
    const numValue = parseInt(value, 10);
    if (!isNaN(numValue)) {
      setFormData((prev) => ({ ...prev, [name]: numValue }));
    }
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      id: "",
      name: "",
      ad_code: "",
      header_code: "",
      footer_code: "",
      ad_enabled: true,
    });
  };

  // Open edit dialog
  const openEditDialog = (placement: AdPlacement) => {
    setCurrentPlacement(placement);
    setFormData({
      id: placement.id,
      name: placement.name,
      ad_code: placement.ad_code || "",
      header_code: placement.header_code || "",
      footer_code: placement.footer_code || "",
      ad_enabled: placement.ad_enabled || false,
    });
    setIsEditDialogOpen(true);
  };

  // Update ad placement
  const updateAdPlacement = async () => {
    try {
      // Check if this is a page-type placement or a model with ad settings
      const isPageType =
        formData.id.includes("-ad") || formData.id.includes("_page");

      const payload = {
        id: formData.id,
        name: formData.name,
        ad_code: formData.ad_code,
        header_code: formData.header_code,
        footer_code: formData.footer_code,
        ad_enabled: Boolean(formData.ad_enabled),
      };

      // If it's a page type, make sure to include these fields
      if (isPageType) {
        Object.assign(payload, {
          type: "page",
          version: "1.0",
          is_active: true,
          description: `Ad placement for ${formData.name}`,
        });
      }

      const response = await fetch("/api/admin/models", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `API error: ${response.status}`);
      }

      // Refresh ad placements list
      fetchAdPlacements();
      resetForm();
      setIsEditDialogOpen(false);
    } catch (err: any) {
      console.error("Error updating ad placement:", err);
      setError(err.message || "Failed to update ad placement");
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold tracking-tight">
          Ad Placements Management
        </h2>
        <Button
          onClick={() => {
            setFormData({
              id: "",
              name: "",
              ad_code: "",
              header_code: "",
              footer_code: "",
              ad_enabled: false,
            });
            setIsAddDialogOpen(true);
          }}
        >
          <PlusCircle className="mr-2 h-4 w-4" /> Add New Placement
        </Button>
      </div>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
          {error}
          <Button
            variant="ghost"
            size="sm"
            className="absolute top-0 right-0 mt-1 mr-1"
            onClick={() => setError(null)}
          >
            ×
          </Button>
        </div>
      )}

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Ad Placements</CardTitle>
            <Button
              variant="outline"
              size="sm"
              onClick={fetchAdPlacements}
              disabled={loading}
            >
              <RefreshCw
                className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`}
              />
              Refresh
            </Button>
          </div>
          <CardDescription>
            Manage ad placements for different models and pages.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center items-center h-40">
              <RefreshCw className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : adPlacements.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground">
              No ad placements found. Configure ad settings for models to get
              started.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Model/Page Name</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {adPlacements.map((placement) => (
                    <TableRow key={placement.id}>
                      <TableCell className="font-medium">
                        {placement.name}
                      </TableCell>
                      <TableCell>
                        {placement.id.includes("top") ? (
                          <span className="px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800">
                            Top
                          </span>
                        ) : placement.id.includes("bottom") ? (
                          <span className="px-2 py-1 rounded-full text-xs bg-purple-100 text-purple-800">
                            Bottom
                          </span>
                        ) : (
                          <span className="px-2 py-1 rounded-full text-xs bg-gray-100 text-gray-800">
                            Other
                          </span>
                        )}
                      </TableCell>
                      <TableCell>
                        <span
                          className={`px-2 py-1 rounded-full text-xs ${placement.ad_enabled ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}
                        >
                          {placement.ad_enabled ? "Enabled" : "Disabled"}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => openEditDialog(placement)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add Ad Placement Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Add New Ad Placement</DialogTitle>
            <DialogDescription>
              Create a new ad placement for a page or section.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="grid gap-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="add-id" className="text-right">
                  Placement ID
                </Label>
                <Input
                  id="add-id"
                  name="id"
                  className="col-span-3"
                  value={formData.id}
                  onChange={handleInputChange}
                  placeholder="unique_page_id"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="add-name" className="text-right">
                  Display Name
                </Label>
                <Input
                  id="add-name"
                  name="name"
                  className="col-span-3"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="Page or Section Name"
                />
              </div>

              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="add-header_code" className="text-right">
                  Header Code
                </Label>
                <Textarea
                  id="add-header_code"
                  name="header_code"
                  className="col-span-3 min-h-[100px] font-mono text-xs"
                  value={formData.header_code}
                  onChange={handleInputChange}
                  placeholder="Paste your header code here (HTML/JavaScript)"
                />
              </div>

              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="add-ad_code" className="text-right">
                  Ad Code
                </Label>
                <Textarea
                  id="add-ad_code"
                  name="ad_code"
                  className="col-span-3 min-h-[150px] font-mono text-xs"
                  value={formData.ad_code}
                  onChange={handleInputChange}
                  placeholder="Paste your ad code here (HTML/JavaScript)"
                />
              </div>

              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="add-footer_code" className="text-right">
                  Footer Code
                </Label>
                <Textarea
                  id="add-footer_code"
                  name="footer_code"
                  className="col-span-3 min-h-[100px] font-mono text-xs"
                  value={formData.footer_code}
                  onChange={handleInputChange}
                  placeholder="Paste your footer code here (HTML/JavaScript)"
                />
              </div>

              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="add-ad_enabled" className="text-right">
                  Enabled
                </Label>
                <div className="col-span-3 flex items-center space-x-2">
                  <Switch
                    id="add-ad_enabled"
                    checked={formData.ad_enabled}
                    onCheckedChange={(checked) =>
                      handleSwitchChange("ad_enabled", checked)
                    }
                  />
                  <Label htmlFor="add-ad_enabled">
                    {formData.ad_enabled ? "Enabled" : "Disabled"}
                  </Label>
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={async () => {
                try {
                  const response = await fetch("/api/admin/models", {
                    method: "POST",
                    headers: {
                      "Content-Type": "application/json",
                    },
                    body: JSON.stringify({
                      ...formData,
                      ad_enabled: Boolean(formData.ad_enabled),
                      type: "page",
                      version: "1.0",
                      is_active: true,
                      description: `Ad placement for ${formData.name}`,
                    }),
                  });

                  if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(
                      errorData.error || `API error: ${response.status}`,
                    );
                  }

                  fetchAdPlacements();
                  setIsAddDialogOpen(false);
                } catch (err: any) {
                  console.error("Error adding ad placement:", err);
                  setError(err.message || "Failed to add ad placement");
                }
              }}
            >
              Add Placement
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Ad Placement Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Edit Ad Placement</DialogTitle>
            <DialogDescription>
              Update the ad settings for this placement.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="grid gap-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-name" className="text-right">
                  Model Name
                </Label>
                <Input
                  id="edit-name"
                  name="name"
                  className="col-span-3"
                  value={formData.name}
                  disabled
                />
              </div>

              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-header_code" className="text-right">
                  Header Code
                </Label>
                <Textarea
                  id="edit-header_code"
                  name="header_code"
                  className="col-span-3 min-h-[100px] font-mono text-xs"
                  value={formData.header_code}
                  onChange={handleInputChange}
                  placeholder="Paste your header code here (HTML/JavaScript)"
                />
              </div>

              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-ad_code" className="text-right">
                  Ad Code
                </Label>
                <Textarea
                  id="edit-ad_code"
                  name="ad_code"
                  className="col-span-3 min-h-[150px] font-mono text-xs"
                  value={formData.ad_code}
                  onChange={handleInputChange}
                  placeholder="Paste your ad code here (HTML/JavaScript)"
                />
              </div>

              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-footer_code" className="text-right">
                  Footer Code
                </Label>
                <Textarea
                  id="edit-footer_code"
                  name="footer_code"
                  className="col-span-3 min-h-[100px] font-mono text-xs"
                  value={formData.footer_code}
                  onChange={handleInputChange}
                  placeholder="Paste your footer code here (HTML/JavaScript)"
                />
              </div>

              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-ad_enabled" className="text-right">
                  Enabled
                </Label>
                <div className="col-span-3 flex items-center space-x-2">
                  <Switch
                    id="edit-ad_enabled"
                    checked={formData.ad_enabled}
                    onCheckedChange={(checked) =>
                      handleSwitchChange("ad_enabled", checked)
                    }
                  />
                  <Label htmlFor="edit-ad_enabled">
                    {formData.ad_enabled ? "Enabled" : "Disabled"}
                  </Label>
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsEditDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button onClick={updateAdPlacement}>Update Ad Settings</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
