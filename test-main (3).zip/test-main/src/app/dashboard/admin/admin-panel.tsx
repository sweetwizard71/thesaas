"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { PlusCircle, Pencil, Trash2, RefreshCw } from "lucide-react";
import AdBlocksPanel from "./ad-blocks-panel";
import AdminNav from "./admin-nav";

type Model = {
  id: string;
  name: string;
  description: string | null;
  type: "chat" | "image";
  version: string;
  is_active: boolean;
  created_at?: string;
  updated_at?: string;
  ad_type?: string;
  ad_code?: string;
  ad_position?: string;
  ad_frequency?: number;
  ad_enabled?: boolean;
};

export default function AdminPanel() {
  const [models, setModels] = useState<Model[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [currentModel, setCurrentModel] = useState<Model | null>(null);

  // Form state
  const [formData, setFormData] = useState<{
    id: string;
    name: string;
    description: string;
    type: "chat" | "image";
    version: string;
    is_active: boolean;
  }>({
    id: "",
    name: "",
    description: "",
    type: "chat",
    version: "",
    is_active: true,
  });

  // Fetch models
  const fetchModels = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/admin/models");
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();
      // Filter out inactive models and page entries
      const filteredModels = (data.models || []).filter(
        (model: Model) => model.is_active && model.type !== "page",
      );
      setModels(filteredModels);
    } catch (err: any) {
      console.error("Error fetching models:", err);
      setError(err.message || "Failed to fetch models");
    } finally {
      setLoading(false);
    }
  };

  // Load models on component mount
  useEffect(() => {
    fetchModels();
  }, []);

  // Handle form input changes
  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Handle select changes
  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Handle switch changes
  const handleSwitchChange = (name: string, checked: boolean) => {
    setFormData((prev) => ({ ...prev, [name]: checked }));
  };

  // Handle number input changes
  const handleNumberChange = (name: string, value: string) => {
    const numValue = parseInt(value, 10);
    if (!isNaN(numValue)) {
      setFormData((prev) => ({ ...prev, [name]: numValue }));
    }
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      id: "",
      name: "",
      description: "",
      type: "chat",
      version: "",
      is_active: true,
    });
  };

  // Open edit dialog
  const openEditDialog = (model: Model) => {
    setCurrentModel(model);
    setFormData({
      id: model.id,
      name: model.name,
      description: model.description || "",
      type: model.type,
      version: model.version,
      is_active: model.is_active,
    });
    setIsEditDialogOpen(true);
  };

  // Add new model
  const addModel = async () => {
    try {
      // Ensure version has a default value if not provided
      const modelData = {
        ...formData,
        version: formData.version || "1.0",
      };

      const response = await fetch("/api/admin/models", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(modelData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `API error: ${response.status}`);
      }

      // Refresh models list
      fetchModels();
      resetForm();
      setIsAddDialogOpen(false);
    } catch (err: any) {
      console.error("Error adding model:", err);
      setError(err.message || "Failed to add model");
    }
  };

  // Update model
  const updateModel = async () => {
    try {
      const response = await fetch("/api/admin/models", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `API error: ${response.status}`);
      }

      // Refresh models list
      fetchModels();
      resetForm();
      setIsEditDialogOpen(false);
    } catch (err: any) {
      console.error("Error updating model:", err);
      setError(err.message || "Failed to update model");
    }
  };

  // Delete model
  const deleteModel = async (id: string) => {
    if (!confirm("Are you sure you want to deactivate this model?")) return;

    try {
      const response = await fetch(`/api/admin/models?id=${id}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `API error: ${response.status}`);
      }

      // Refresh models list
      fetchModels();
    } catch (err: any) {
      console.error("Error deleting model:", err);
      setError(err.message || "Failed to delete model");
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold tracking-tight">Admin Dashboard</h2>
        <Button onClick={() => setIsAddDialogOpen(true)}>
          <PlusCircle className="mr-2 h-4 w-4" /> Add New Model
        </Button>
      </div>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
          {error}
          <Button
            variant="ghost"
            size="sm"
            className="absolute top-0 right-0 mt-1 mr-1"
            onClick={() => setError(null)}
          >
            ×
          </Button>
        </div>
      )}

      <AdminNav />

      <div className="mt-4">
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Available AI Models</CardTitle>
              <Button
                variant="outline"
                size="sm"
                onClick={fetchModels}
                disabled={loading}
              >
                <RefreshCw
                  className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`}
                />
                Refresh
              </Button>
            </div>
            <CardDescription>
              Manage the active AI models available for chat and image
              generation.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center items-center h-40">
                <RefreshCw className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : models.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground">
                No models found. Add your first model to get started.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>ID</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Version</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {models.map((model) => (
                      <TableRow key={model.id}>
                        <TableCell className="font-medium">
                          {model.name}
                        </TableCell>
                        <TableCell className="font-mono text-xs">
                          {model.id}
                        </TableCell>
                        <TableCell>
                          <span
                            className={`px-2 py-1 rounded-full text-xs ${model.type === "chat" ? "bg-blue-100 text-blue-800" : "bg-purple-100 text-purple-800"}`}
                          >
                            {model.type}
                          </span>
                        </TableCell>
                        <TableCell className="font-mono text-xs truncate max-w-[150px]">
                          {model.version}
                        </TableCell>
                        <TableCell>
                          <span
                            className={`px-2 py-1 rounded-full text-xs ${model.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}
                          >
                            {model.is_active ? "Active" : "Inactive"}
                          </span>
                        </TableCell>

                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openEditDialog(model)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteModel(model.id)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Add Model Dialog */}
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Add New AI Model</DialogTitle>
              <DialogDescription>
                Add a new model to the platform. All fields are required.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div className="grid gap-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="id" className="text-right">
                    Model ID
                  </Label>
                  <Input
                    id="id"
                    name="id"
                    placeholder="organization/model-name"
                    className="col-span-3"
                    value={formData.id}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="name" className="text-right">
                    Display Name
                  </Label>
                  <Input
                    id="name"
                    name="name"
                    placeholder="User-friendly name"
                    className="col-span-3"
                    value={formData.name}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="description" className="text-right">
                    Description
                  </Label>
                  <Textarea
                    id="description"
                    name="description"
                    placeholder="Brief description of the model"
                    className="col-span-3"
                    value={formData.description}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="type" className="text-right">
                    Type
                  </Label>
                  <Select
                    value={formData.type}
                    onValueChange={(value) => handleSelectChange("type", value)}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select model type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="chat">Chat</SelectItem>
                      <SelectItem value="image">Image</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="version" className="text-right">
                    Version ID
                  </Label>
                  <Input
                    id="version"
                    name="version"
                    placeholder="Model version hash or identifier"
                    className="col-span-3"
                    value={formData.version}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="is_active" className="text-right">
                    Active
                  </Label>
                  <div className="col-span-3 flex items-center space-x-2">
                    <Switch
                      id="is_active"
                      checked={formData.is_active}
                      onCheckedChange={(checked) =>
                        handleSwitchChange("is_active", checked)
                      }
                    />
                    <Label htmlFor="is_active">
                      {formData.is_active ? "Active" : "Inactive"}
                    </Label>
                  </div>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsAddDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button onClick={addModel}>Add Model</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit Model Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Edit AI Model</DialogTitle>
              <DialogDescription>
                Update the model details. Model ID cannot be changed.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div className="grid gap-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="edit-id" className="text-right">
                    Model ID
                  </Label>
                  <Input
                    id="edit-id"
                    name="id"
                    className="col-span-3"
                    value={formData.id}
                    disabled
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="edit-name" className="text-right">
                    Display Name
                  </Label>
                  <Input
                    id="edit-name"
                    name="name"
                    className="col-span-3"
                    value={formData.name}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="edit-description" className="text-right">
                    Description
                  </Label>
                  <Textarea
                    id="edit-description"
                    name="description"
                    className="col-span-3"
                    value={formData.description}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="edit-type" className="text-right">
                    Type
                  </Label>
                  <Select
                    value={formData.type}
                    onValueChange={(value) => handleSelectChange("type", value)}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select model type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="chat">Chat</SelectItem>
                      <SelectItem value="image">Image</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="edit-version" className="text-right">
                    Version ID
                  </Label>
                  <Input
                    id="edit-version"
                    name="version"
                    className="col-span-3"
                    value={formData.version}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="edit-is_active" className="text-right">
                    Active
                  </Label>
                  <div className="col-span-3 flex items-center space-x-2">
                    <Switch
                      id="edit-is_active"
                      checked={formData.is_active}
                      onCheckedChange={(checked) =>
                        handleSwitchChange("is_active", checked)
                      }
                    />
                    <Label htmlFor="edit-is_active">
                      {formData.is_active ? "Active" : "Inactive"}
                    </Label>
                  </div>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsEditDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button onClick={updateModel}>Update Model</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
