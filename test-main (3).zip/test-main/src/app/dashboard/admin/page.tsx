import AdminPanel from "./admin-panel";

export default function AdminPage() {
  return (
    <div className="container mx-auto py-6">
      <AdminPanel />
    </div>
  );
}
