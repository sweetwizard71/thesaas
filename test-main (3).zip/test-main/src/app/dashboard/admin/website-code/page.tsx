"use client";

import { useEffect } from "react";
import AdBlocksPanel from "../ad-blocks-panel";
import AdminNav from "../admin-nav";

export default function WebsiteCodePage() {
  // Add client-side navigation highlighting
  useEffect(() => {
    // This is just to ensure the component re-renders on the client
    // The actual highlighting is handled by the className logic in the nav
  }, []);

  return (
    <>
      <AdminNav />
      <AdBlocksPanel />
    </>
  );
}
