"use client";

import { usePathname } from "next/navigation";

export default function AdminNav() {
  const pathname = usePathname();

  return (
    <div className="mb-6">
      <div className="bg-white rounded-lg shadow-sm border">
        <nav className="flex" aria-label="Tabs">
          <a
            href="/dashboard/admin"
            className={`flex-1 text-center py-3 px-4 font-medium text-sm border-b-2 ${pathname === "/dashboard/admin" ? "border-primary text-primary" : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"}`}
          >
            Models
          </a>
          <a
            href="/dashboard/admin/website-code"
            className={`flex-1 text-center py-3 px-4 font-medium text-sm border-b-2 ${pathname === "/dashboard/admin/website-code" ? "border-primary text-primary" : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"}`}
          >
            Website Code
          </a>
          <a
            href="/dashboard/admin/ads"
            className={`flex-1 text-center py-3 px-4 font-medium text-sm border-b-2 ${pathname === "/dashboard/admin/ads" ? "border-primary text-primary" : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"}`}
          >
            Ad Management
          </a>
        </nav>
      </div>
    </div>
  );
}
