"use client";

import { useEffect } from "react";
import AdminAdManagement from "../admin-ad-management";
import AdminNav from "../admin-nav";

export default function AdminAdsPage() {
  // Add client-side navigation highlighting
  useEffect(() => {
    // This is just to ensure the component re-renders on the client
    // The actual highlighting is handled by the className logic in the nav
  }, []);

  return (
    <>
      <AdminNav />
      <AdminAdManagement />
    </>
  );
}
