import { redirect } from "next/navigation";
import { createClient } from "../../../../supabase/server";
import DashboardNavbar from "@/components/dashboard-navbar";
import { InfoIcon } from "lucide-react";
import ImageGenerator from "./image-generator";
import { AdComponent } from "@/components/ad-component";

export default async function ImagesPage() {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return redirect("/sign-in");
  }

  // Fetch ad settings for image generator from database
  const { data: imageGeneratorAd } = await supabase
    .from("ai_models")
    .select("*")
    .eq("id", "image-generator-top-ad")
    .single();

  // Default ad settings if none found
  const imageGeneratorAdSettings = {
    adCode: imageGeneratorAd?.ad_code || "",
    isEnabled: imageGeneratorAd?.ad_enabled || false,
  };

  return (
    <>
      <DashboardNavbar />
      <main className="w-full">
        <div className="container mx-auto px-4 py-8 flex flex-col gap-8">
          {/* Header Section */}
          <header className="flex flex-col gap-4">
            <h1 className="text-3xl font-bold">Image Generation</h1>
            <div className="bg-secondary/50 text-sm p-3 px-4 rounded-lg text-muted-foreground flex gap-2 items-center">
              <InfoIcon size="14" />
              <span>
                Generate images using AI models powered by Replicate API
              </span>
            </div>
          </header>

          {/* Ad Block - Top Position */}
          {imageGeneratorAdSettings.isEnabled && (
            <div id="image-generator-top-ad" className="w-full mb-6">
              <AdComponent
                settings={imageGeneratorAdSettings}
                className="w-full"
                id="image-generator-top-ad-component"
              />
            </div>
          )}

          {/* Image Generation Interface */}
          <ImageGenerator />
        </div>
      </main>
    </>
  );
}
