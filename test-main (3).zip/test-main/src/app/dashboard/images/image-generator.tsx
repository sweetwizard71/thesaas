"use client";

import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { Download, RefreshCw, Upload, X } from "lucide-react";
import { imageModels, refreshModels } from "@/lib/replicate";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { AdComponent, AdSettings } from "@/components/ad-component";

type GeneratedImage = {
  id: string;
  url: string;
  originalUrl?: string; // Store the original URL for downloading
  prompt: string;
  model: string;
  timestamp: number;
  deleted?: boolean; // Track if image is deleted
  imagePromptUrl?: string; // URL of the image used as a prompt
};

export default function ImageGenerator() {
  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentImage, setCurrentImage] = useState<string | null>(null);
  const [model, setModel] = useState(imageModels[0].id);
  const [resolution, setResolution] = useState("1024x1024");
  const [gallery, setGallery] = useState<GeneratedImage[]>([]);
  const [currentOriginalUrl, setCurrentOriginalUrl] = useState<string | null>(
    null,
  );
  const [imagePrompt, setImagePrompt] = useState<string | null>(null);
  const [imagePromptPreview, setImagePromptPreview] = useState<string | null>(
    null,
  );
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [adSettings, setAdSettings] = useState<AdSettings>({
    adType: "banner",
    adCode: "",
    adPosition: "top",
    isEnabled: false,
  });

  // Load models and gallery from localStorage
  useEffect(() => {
    // Refresh models from database
    refreshModels();

    // Fetch ad settings from database
    const fetchAdSettings = async () => {
      try {
        const response = await fetch("/api/admin/models");
        if (response.ok) {
          const data = await response.json();
          const imageGeneratorAd = data.models.find(
            (m: any) => m.id === "image-generator-top-ad",
          );

          if (imageGeneratorAd) {
            setAdSettings({
              adType: imageGeneratorAd.ad_type || "banner",
              adCode: imageGeneratorAd.ad_code || "",
              adPosition: "top",
              isEnabled: imageGeneratorAd.ad_enabled || false,
            });
          }
        }
      } catch (error) {
        console.error("Error fetching ad settings:", error);
      }
    };

    fetchAdSettings();

    const savedGallery = localStorage.getItem("imageGallery");
    if (savedGallery) {
      try {
        setGallery(JSON.parse(savedGallery));
      } catch (e) {
        console.error("Failed to parse saved gallery", e);
      }
    }
  }, []);

  // Save gallery to localStorage
  useEffect(() => {
    if (gallery.length > 0) {
      try {
        localStorage.setItem("imageGallery", JSON.stringify(gallery));
        console.log("Saved gallery to localStorage:", gallery.length, "items");
      } catch (error) {
        console.error("Failed to save gallery to localStorage:", error);
      }
    }
  }, [gallery]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file size (limit to 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert("File size must be less than 5MB");
      return;
    }

    // Check file type
    if (!file.type.startsWith("image/")) {
      alert("File must be an image");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      setImagePromptPreview(base64);

      // Use the base64 data directly instead of uploading to Supabase
      setImagePrompt(base64);
    };
    reader.readAsDataURL(file);
  };

  const removeUploadedImage = () => {
    setImagePrompt(null);
    setImagePromptPreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const generateImage = async () => {
    if (!prompt.trim()) return;

    setIsGenerating(true);
    setCurrentImage(null);
    setCurrentOriginalUrl(null);

    try {
      // Find the model version from the imageModels array
      const selectedModel = imageModels.find((m) => m.id === model);
      if (!selectedModel) {
        throw new Error(`Model ${model} not found`);
      }

      const response = await fetch("/api/replicate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          type: "image",
          prompt: prompt,
          modelId: model,
          resolution: resolution,
          imagePrompt: imagePrompt || undefined,
        }),
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();

      console.log("Full API response:", JSON.stringify(data, null, 2));
      // Display the response in the console as a table for easier debugging
      console.table(data);

      // Log additional debugging information about the response structure
      console.log("Response type:", typeof data);
      if (data && typeof data === "object") {
        console.log("Response keys:", Object.keys(data));
        if (data.debug && data.debug.rawOutput) {
          console.log("Raw output type:", typeof data.debug.rawOutput);
          if (Array.isArray(data.debug.rawOutput)) {
            console.log(
              "Raw output array length:",
              data.debug.rawOutput.length,
            );
            data.debug.rawOutput.forEach((item, index) => {
              console.log(`Raw output[${index}]:`, item);
            });
          }
        }
      }

      // Handle the image URL with improved error handling
      if (data.error) {
        console.error("API error:", data.error);
        setCurrentImage(
          "https://images.unsplash.com/photo-1682687982501-1e58ab814714?w=800&q=80",
        );
      } else {
        let imageUrl = null;

        // First check if we have originalUrl (direct URL from API)
        if (data.originalUrl && typeof data.originalUrl === "string") {
          imageUrl = data.originalUrl;
          console.log("Using originalUrl:", imageUrl);
        } else if (data.imageUrl && typeof data.imageUrl === "string") {
          // Direct URL string
          imageUrl = data.imageUrl;
          console.log("Using string imageUrl:", imageUrl);
        } else if (
          data.imageUrl &&
          typeof data.imageUrl === "object" &&
          data.imageUrl !== null
        ) {
          // Handle case where imageUrl is an object
          console.log("imageUrl is an object:", JSON.stringify(data.imageUrl));

          // Try to extract URL from common patterns
          if (Array.isArray(data.imageUrl) && data.imageUrl.length > 0) {
            imageUrl = data.imageUrl[0];
            console.log("Extracted from array:", imageUrl);
          } else if (data.imageUrl.url) {
            imageUrl = data.imageUrl.url;
            console.log("Extracted from url property:", imageUrl);
          } else if (
            data.imageUrl.output &&
            Array.isArray(data.imageUrl.output)
          ) {
            imageUrl = data.imageUrl.output[0];
            console.log("Extracted from output array:", imageUrl);
          } else if (
            data.imageUrl.images &&
            Array.isArray(data.imageUrl.images)
          ) {
            imageUrl = data.imageUrl.images[0];
            console.log("Extracted from images array:", imageUrl);
          } else if (
            data.imageUrl.output &&
            typeof data.imageUrl.output === "string"
          ) {
            imageUrl = data.imageUrl.output;
            console.log("Extracted from output string:", imageUrl);
          }
        }

        // If we have a valid URL, use it; otherwise use fallback
        if (imageUrl && typeof imageUrl === "string") {
          try {
            // Validate URL format
            new URL(imageUrl);

            // Use our proxy endpoint to bypass CORS restrictions
            const proxyUrl = `/api/proxy-image?url=${encodeURIComponent(imageUrl)}`;
            console.log("Using proxy URL:", proxyUrl);
            setCurrentImage(proxyUrl);
            setCurrentOriginalUrl(imageUrl);
          } catch (error) {
            console.error("Invalid URL format:", error, imageUrl);
            setCurrentImage(
              "https://images.unsplash.com/photo-1682687982501-1e58ab814714?w=800&q=80",
            );
          }
        } else if (data.debug && data.debug.rawOutput) {
          // Try to extract URL from debug data if available
          console.log("Attempting to extract URL from debug data", data.debug);

          let debugUrl = null;
          const rawOutput = data.debug.rawOutput;

          if (
            Array.isArray(rawOutput) &&
            rawOutput.length > 0 &&
            typeof rawOutput[0] === "string"
          ) {
            debugUrl = rawOutput[0];
            console.log("Extracted URL from debug array:", debugUrl);
          } else if (
            typeof rawOutput === "string" &&
            rawOutput.startsWith("http")
          ) {
            debugUrl = rawOutput;
            console.log("Using debug string URL directly:", debugUrl);
          } else if (rawOutput && typeof rawOutput === "object") {
            // Try to find any property that might contain a URL
            for (const key in rawOutput) {
              if (
                typeof rawOutput[key] === "string" &&
                rawOutput[key].startsWith("http")
              ) {
                debugUrl = rawOutput[key];
                console.log(`Extracted URL from debug.${key}:`, debugUrl);
                break;
              } else if (
                Array.isArray(rawOutput[key]) &&
                rawOutput[key].length > 0 &&
                typeof rawOutput[key][0] === "string" &&
                rawOutput[key][0].startsWith("http")
              ) {
                debugUrl = rawOutput[key][0];
                console.log(`Extracted URL from debug.${key}[0]:`, debugUrl);
                break;
              }
            }
          }

          if (debugUrl) {
            try {
              new URL(debugUrl);
              const proxyUrl = `/api/proxy-image?url=${encodeURIComponent(debugUrl)}`;
              console.log("Using proxy URL from debug data:", proxyUrl);
              setCurrentImage(proxyUrl);
              setCurrentOriginalUrl(debugUrl);
            } catch (error) {
              console.error("Invalid debug URL format:", error, debugUrl);
              setCurrentImage(
                "https://images.unsplash.com/photo-1682687982501-1e58ab814714?w=800&q=80",
              );
            }
          } else {
            console.error("Could not extract valid image URL from debug data");
            setCurrentImage(
              "https://images.unsplash.com/photo-1682687982501-1e58ab814714?w=800&q=80",
            );
          }
        } else {
          console.error("Could not extract valid image URL");
          setCurrentImage(
            "https://images.unsplash.com/photo-1682687982501-1e58ab814714?w=800&q=80",
          );
        }
      }

      // Add to gallery with proxied URL
      // Wait for currentImage to be set before adding to gallery
      setTimeout(() => {
        let galleryUrl = currentImage; // Use the same URL we're displaying
        let originalUrl = currentOriginalUrl || "";

        // If we don't have a current image yet but have data.imageUrl or data.originalUrl, try to use that
        if (!galleryUrl) {
          if (data.originalUrl && typeof data.originalUrl === "string") {
            try {
              new URL(data.originalUrl);
              originalUrl = data.originalUrl;
              galleryUrl = `/api/proxy-image?url=${encodeURIComponent(data.originalUrl)}`;
              console.log(
                "Using originalUrl for gallery from data:",
                data.originalUrl,
              );
            } catch (error) {
              console.error("Invalid originalUrl for gallery:", error);
            }
          } else if (data.imageUrl && typeof data.imageUrl === "string") {
            try {
              new URL(data.imageUrl);
              originalUrl = data.imageUrl;
              galleryUrl = `/api/proxy-image?url=${encodeURIComponent(data.imageUrl)}`;
              console.log(
                "Using imageUrl for gallery from data:",
                data.imageUrl,
              );
            } catch (error) {
              console.error("Invalid imageUrl for gallery:", error);
            }
          }

          // If still no valid URL, use fallback
          if (!galleryUrl) {
            galleryUrl =
              "https://images.unsplash.com/photo-1682687982501-1e58ab814714?w=800&q=80";
            console.log("Using fallback image for gallery");
          }
        }

        const newImage: GeneratedImage = {
          id: Date.now().toString(),
          url: galleryUrl,
          originalUrl: originalUrl, // Store original URL for downloading
          prompt: prompt,
          model: model,
          timestamp: Date.now(),
          imagePromptUrl: imagePromptPreview || undefined,
        };

        setGallery((prev) => [newImage, ...prev]);
      }, 100); // Small delay to ensure state is updated
    } catch (error) {
      console.error("Error generating image:", error);
      alert("Sorry, there was an error generating your image.");
    } finally {
      setIsGenerating(false);
    }
  };

  const deleteImage = (id: string) => {
    setGallery((prev) =>
      prev.map((img) => (img.id === id ? { ...img, deleted: true } : img)),
    );
  };

  const downloadImage = (
    url: string,
    originalUrl?: string,
    filename = "generated-image.png",
  ) => {
    try {
      // If we have the original URL and it's from Replicate, use it for download
      // Otherwise use the proxy URL
      let downloadUrl = url;

      if (originalUrl && typeof originalUrl === "string") {
        try {
          // Validate URL format
          new URL(originalUrl);
          if (
            originalUrl.includes("replicate.delivery") ||
            originalUrl.includes("replicate.com")
          ) {
            downloadUrl = `/api/proxy-image?url=${encodeURIComponent(originalUrl)}`;
          }
        } catch (error) {
          console.error(
            "Invalid originalUrl format for download:",
            error,
            originalUrl,
          );
        }
      }

      console.log("Downloading from URL:", downloadUrl);

      const a = document.createElement("a");
      a.href = downloadUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (error) {
      console.error("Error downloading image:", error);
      alert("Unable to download this image. Please try again later.");
    }
  };

  const regenerateImage = () => {
    generateImage();
  };

  return (
    <>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Image Display Area */}
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle>Generated Image</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-muted/30 rounded-lg p-4 mb-4">
              <AspectRatio
                ratio={16 / 9}
                className="bg-muted overflow-hidden rounded-md"
              >
                {currentImage ? (
                  <img
                    src={currentImage}
                    alt="Generated image"
                    className="object-cover w-full h-full"
                  />
                ) : (
                  <div className="flex items-center justify-center h-full">
                    {isGenerating ? (
                      <LoadingSpinner
                        size="lg"
                        text="Generating your image..."
                      />
                    ) : (
                      <p className="text-muted-foreground">
                        Your generated image will appear here
                      </p>
                    )}
                  </div>
                )}
              </AspectRatio>
            </div>
            <div className="flex justify-end gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={!currentImage || isGenerating}
                onClick={() =>
                  currentImage &&
                  downloadImage(currentImage, currentOriginalUrl || undefined)
                }
              >
                <Download className="h-4 w-4 mr-2" />
                Download
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={!prompt.trim() || isGenerating}
                onClick={regenerateImage}
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Regenerate
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Settings Panel */}
        <Card>
          <CardHeader>
            <CardTitle>Image Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Select Model</label>
              <Select value={model} onValueChange={setModel}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a model" />
                </SelectTrigger>
                <SelectContent>
                  {imageModels.map((model) => (
                    <SelectItem key={model.id} value={model.id}>
                      {model.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Image Prompt</label>
              <Textarea
                placeholder="Describe the image you want to generate..."
                className="resize-none min-h-[100px]"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                disabled={isGenerating}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">
                Upload Reference Image (Optional)
              </label>
              <div className="border-2 border-dashed border-muted-foreground/25 rounded-md p-4 text-center cursor-pointer hover:bg-muted/50 transition-colors">
                {imagePromptPreview ? (
                  <div className="relative">
                    <img
                      src={imagePromptPreview}
                      alt="Uploaded reference"
                      className="max-h-[150px] mx-auto rounded-md"
                    />
                    <Button
                      variant="destructive"
                      size="icon"
                      className="absolute top-1 right-1 h-6 w-6"
                      onClick={(e) => {
                        e.stopPropagation();
                        removeUploadedImage();
                      }}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <div
                    className="flex flex-col items-center justify-center gap-2 py-4"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Upload className="h-8 w-8 text-muted-foreground" />
                    <p className="text-sm text-muted-foreground">
                      Click to upload a reference image
                    </p>
                    <p className="text-xs text-muted-foreground/70">
                      PNG, JPG or WebP (max. 5MB)
                    </p>
                  </div>
                )}
                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  accept="image/*"
                  onChange={handleImageUpload}
                  disabled={isGenerating}
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Resolution</label>
              <Select value={resolution} onValueChange={setResolution}>
                <SelectTrigger>
                  <SelectValue placeholder="Select resolution" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="512x512">512 x 512</SelectItem>
                  <SelectItem value="768x768">768 x 768</SelectItem>
                  <SelectItem value="1024x1024">1024 x 1024</SelectItem>
                  <SelectItem value="1024x1792">
                    1024 x 1792 (Portrait)
                  </SelectItem>
                  <SelectItem value="1792x1024">
                    1792 x 1024 (Landscape)
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button
              className="w-full"
              onClick={generateImage}
              disabled={!prompt.trim() || isGenerating}
            >
              {isGenerating ? "Generating..." : "Generate Image"}
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Ad Block - Image Generator Top */}
      {adSettings.isEnabled && (
        <div id="image-generator-top-ad" className="w-full my-6">
          <AdComponent
            settings={adSettings}
            className="w-full"
            id="image-generator-top-ad-component"
          />
        </div>
      )}

      {/* Image Gallery */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle>History</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {gallery.length > 0 ? (
              gallery
                .filter((image) => !image.deleted)
                .map((image) => (
                  <div
                    key={image.id}
                    className="relative group overflow-hidden rounded-md"
                  >
                    <AspectRatio ratio={1} className="bg-muted">
                      <img
                        src={
                          image.url ||
                          "https://images.unsplash.com/photo-1682687982501-1e58ab814714?w=800&q=80"
                        }
                        alt={image.prompt}
                        className={`object-cover w-full h-full ${image.deleted ? "opacity-60" : ""}`}
                        onError={(e) => {
                          console.error("Image failed to load:", image.url);
                          (e.target as HTMLImageElement).src =
                            "https://images.unsplash.com/photo-1682687982501-1e58ab814714?w=800&q=80";
                        }}
                      />
                    </AspectRatio>
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-white"
                        onClick={() =>
                          downloadImage(image.url, image.originalUrl)
                        }
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                      {!image.deleted && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-white hover:text-red-400"
                          onClick={() => deleteImage(image.id)}
                        >
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="lucide lucide-trash-2"
                          >
                            <path d="M3 6h18" />
                            <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                            <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                            <line x1="10" x2="10" y1="11" y2="17" />
                            <line x1="14" x2="14" y1="11" y2="17" />
                          </svg>
                        </Button>
                      )}
                    </div>
                  </div>
                ))
            ) : (
              <div className="col-span-full text-center py-8 text-muted-foreground">
                No images generated yet. Create your first image above!
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </>
  );
}
