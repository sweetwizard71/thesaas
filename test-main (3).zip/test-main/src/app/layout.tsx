import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Script from "next/script";
import { TempoInit } from "@/components/tempo-init";
import { ThemeProvider } from "@/components/theme-provider";
import { createClient } from "../../supabase/server";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Tempo - Modern SaaS Starter",
  description: "A modern full-stack starter template powered by Next.js",
};

async function getAdBlocks() {
  try {
    const supabase = await createClient();
    const { data } = await supabase
      .from("ad_blocks")
      .select("location, html_code, active")
      .in("location", ["header", "footer"]);

    const headerBlock = data?.find((block) => block.location === "header");
    const footerBlock = data?.find((block) => block.location === "footer");

    return {
      headerCode: (headerBlock?.active && headerBlock?.html_code) || "",
      footerCode: (footerBlock?.active && footerBlock?.html_code) || "",
    };
  } catch (error) {
    console.error("Error fetching ad blocks:", error);
    return { headerCode: "", footerCode: "" };
  }
}

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const { headerCode, footerCode } = await getAdBlocks();

  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <Script src="https://api.tempolabs.ai/proxy-asset?url=https://storage.googleapis.com/tempo-public-assets/error-handling.js" />
        {headerCode && (
          <Script
            id="custom-header-code"
            dangerouslySetInnerHTML={{ __html: headerCode }}
            strategy="beforeInteractive"
          />
        )}
      </head>
      <body className={inter.className}>
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          disableTransitionOnChange
        >
          {children}
        </ThemeProvider>
        <TempoInit />
        {footerCode && (
          <Script
            id="custom-footer-code"
            dangerouslySetInnerHTML={{ __html: footerCode }}
            strategy="afterInteractive"
          />
        )}
      </body>
    </html>
  );
}
