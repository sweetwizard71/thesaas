import Footer from "@/components/footer";
import Hero from "@/components/hero";
import Navbar from "@/components/navbar";
import {
  ArrowUpRight,
  BrainCircuit,
  Image,
  MessageSquare,
  Settings,
  Shield,
  Sparkles,
  Zap,
} from "lucide-react";
import { createClient } from "../../supabase/server";

export default async function Home() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-50">
      <Navbar />
      <Hero />

      {/* Features Section */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">AI-Powered Features</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Harness the power of cutting-edge AI models through our intuitive
              platform with Replicate API integration.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <MessageSquare className="w-6 h-6" />,
                title: "AI Chat Models",
                description:
                  "Interact with various AI chat models through a unified interface",
              },
              {
                icon: <Image className="w-6 h-6" />,
                title: "Image Generation",
                description:
                  "Create stunning images from text prompts with leading AI models",
              },
              {
                icon: <BrainCircuit className="w-6 h-6" />,
                title: "Model Switching",
                description:
                  "Seamlessly switch between different AI models for your needs",
              },
              {
                icon: <Settings className="w-6 h-6" />,
                title: "Admin Controls",
                description:
                  "Configure models and API settings through an intuitive dashboard",
              },
            ].map((feature, index) => (
              <div
                key={index}
                className="p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="text-purple-600 mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">How It Works</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our platform makes AI interaction simple and accessible for
              everyone
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-purple-600 text-xl font-bold">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">
                Choose Your Feature
              </h3>
              <p className="text-gray-600">
                Select between chat interaction or image generation based on
                your needs
              </p>
            </div>
            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-purple-600 text-xl font-bold">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">Select AI Model</h3>
              <p className="text-gray-600">
                Pick from our curated selection of top-performing AI models
              </p>
            </div>
            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-purple-600 text-xl font-bold">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">Create & Save</h3>
              <p className="text-gray-600">
                Generate content and save your history for future reference
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-purple-600 text-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold mb-2">20+</div>
              <div className="text-purple-100">AI Models Available</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">1000+</div>
              <div className="text-purple-100">Daily Generations</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">100%</div>
              <div className="text-purple-100">Secure Storage</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">
            Start Creating with AI Today
          </h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Join our platform and unlock the full potential of AI for chat and
            image generation.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/dashboard"
              className="inline-flex items-center px-6 py-3 text-white bg-purple-600 rounded-lg hover:bg-purple-700 transition-colors"
            >
              Try for Free
              <ArrowUpRight className="ml-2 w-4 h-4" />
            </a>
            <a
              href="#features"
              className="inline-flex items-center px-6 py-3 text-purple-700 bg-purple-100 rounded-lg hover:bg-purple-200 transition-colors"
            >
              Learn More
              <Sparkles className="ml-2 w-4 h-4" />
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
