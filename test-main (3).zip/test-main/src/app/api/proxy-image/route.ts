import { NextRequest, NextResponse } from "next/server";
import { createClient } from "../../../../supabase/server";

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient();

    // Check authentication
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get the image URL from the query parameter
    const { searchParams } = new URL(request.url);
    const imageUrl = searchParams.get("url");

    if (!imageUrl) {
      return NextResponse.json(
        { error: "Missing image URL parameter" },
        { status: 400 },
      );
    }

    // Ensure imageUrl is a string and properly formatted
    if (!imageUrl || typeof imageUrl !== "string") {
      console.error(
        "Invalid image URL type:",
        typeof imageUrl,
        JSON.stringify(imageUrl),
      );
      // Return a fallback image instead of an error
      const fallbackUrl =
        "https://images.unsplash.com/photo-1682687982501-1e58ab814714?w=800&q=80";
      const fallbackResponse = await fetch(fallbackUrl);
      const fallbackData = await fallbackResponse.arrayBuffer();
      const fallbackContentType =
        fallbackResponse.headers.get("content-type") || "image/jpeg";

      return new NextResponse(fallbackData, {
        headers: {
          "Content-Type": fallbackContentType,
          "Cache-Control": "public, max-age=86400",
          "Access-Control-Allow-Origin": "*",
        },
      });
    }

    // Validate URL format before attempting to fetch
    try {
      new URL(imageUrl);
    } catch (error) {
      console.error(`Invalid URL format: ${imageUrl}`);
      // Return a fallback image instead of an error
      const fallbackUrl =
        "https://images.unsplash.com/photo-1682687982501-1e58ab814714?w=800&q=80";
      const fallbackResponse = await fetch(fallbackUrl);
      const fallbackData = await fallbackResponse.arrayBuffer();
      const fallbackContentType =
        fallbackResponse.headers.get("content-type") || "image/jpeg";

      return new NextResponse(fallbackData, {
        headers: {
          "Content-Type": fallbackContentType,
          "Cache-Control": "public, max-age=86400",
          "Access-Control-Allow-Origin": "*",
        },
      });
    }

    // Fetch the image from the original URL
    try {
      console.log(`Attempting to fetch image from: ${imageUrl}`);

      // Add custom headers to handle potential CORS or authentication issues
      const response = await fetch(imageUrl, {
        headers: {
          // Some image hosts might require a user agent
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          // Add a referer to avoid some restrictions
          Referer: "https://replicate.com/",
        },
        // Increase timeout for large images
        signal: AbortSignal.timeout(15000), // 15 second timeout
      });

      if (!response.ok) {
        console.error(
          `Failed to fetch image: ${response.status} ${response.statusText}`,
        );
        console.error(
          `Response headers:`,
          Object.fromEntries(response.headers.entries()),
        );

        // Return a fallback image instead of an error
        const fallbackUrl =
          "https://images.unsplash.com/photo-1682687982501-1e58ab814714?w=800&q=80";
        const fallbackResponse = await fetch(fallbackUrl);
        const fallbackData = await fallbackResponse.arrayBuffer();
        const fallbackContentType =
          fallbackResponse.headers.get("content-type") || "image/jpeg";

        return new NextResponse(fallbackData, {
          headers: {
            "Content-Type": fallbackContentType,
            "Cache-Control": "public, max-age=86400",
            "Access-Control-Allow-Origin": "*",
          },
        });
      }

      return new NextResponse(await response.arrayBuffer(), {
        headers: {
          "Content-Type": response.headers.get("content-type") || "image/png",
          "Cache-Control": "public, max-age=86400",
          "Access-Control-Allow-Origin": "*",
        },
      });
    } catch (error) {
      console.error("Error fetching image:", error);
      // Return a fallback image instead of an error
      const fallbackUrl =
        "https://images.unsplash.com/photo-1682687982501-1e58ab814714?w=800&q=80";
      const fallbackResponse = await fetch(fallbackUrl);
      const fallbackData = await fallbackResponse.arrayBuffer();
      const fallbackContentType =
        fallbackResponse.headers.get("content-type") || "image/jpeg";

      return new NextResponse(fallbackData, {
        headers: {
          "Content-Type": fallbackContentType,
          "Cache-Control": "public, max-age=86400",
          "Access-Control-Allow-Origin": "*",
        },
      });
    }

    // This code is now handled in the try/catch block above
  } catch (error: any) {
    console.error("Error in proxy image route:", error);
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: 500 },
    );
  }
}
