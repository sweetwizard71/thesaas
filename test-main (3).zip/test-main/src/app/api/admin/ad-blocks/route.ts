import { NextRequest, NextResponse } from "next/server";
import { createClient } from "../../../../../supabase/server";

// Helper function to check if user is admin
async function isAdmin(supabase: any) {
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return false;
  }

  // Get user profile from the database to check admin status
  const { data: userProfile } = await supabase
    .from("users")
    .select("is_admin")
    .eq("id", user.id)
    .single();

  return userProfile?.is_admin === true;
}

// GET all ad blocks
export async function GET() {
  try {
    const supabase = await createClient();

    // Check authentication
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check if user is admin
    if (!(await isAdmin(supabase))) {
      return NextResponse.json(
        { error: "Unauthorized: Admin access required" },
        { status: 403 },
      );
    }

    // Get all ad blocks
    const { data: adBlocks, error } = await supabase
      .from("ad_blocks")
      .select("*")
      .order("location", { ascending: true });

    if (error) {
      console.error("Error fetching ad blocks:", error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ adBlocks });
  } catch (error: any) {
    console.error("Error in GET ad blocks:", error);
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: 500 },
    );
  }
}

// POST new ad block
export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient();

    // Check if user is admin
    if (!(await isAdmin(supabase))) {
      return NextResponse.json(
        { error: "Unauthorized: Admin access required" },
        { status: 403 },
      );
    }

    // Get request body
    const body = await request.json();
    const { location, html_code, active } = body;

    if (!location) {
      return NextResponse.json(
        { error: "Missing required field: location" },
        { status: 400 },
      );
    }

    // Insert new ad block
    const { data, error } = await supabase
      .from("ad_blocks")
      .insert([
        {
          location,
          html_code: html_code || "",
          active: active !== undefined ? active : true,
          updated_at: new Date().toISOString(),
        },
      ])
      .select();

    if (error) {
      console.error("Error creating ad block:", error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ adBlock: data[0] });
  } catch (error: any) {
    console.error("Error in POST ad block:", error);
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: 500 },
    );
  }
}

// PUT update ad block
export async function PUT(request: NextRequest) {
  try {
    const supabase = await createClient();

    // Check if user is admin
    if (!(await isAdmin(supabase))) {
      return NextResponse.json(
        { error: "Unauthorized: Admin access required" },
        { status: 403 },
      );
    }

    // Get request body
    const body = await request.json();
    const { id, location, html_code, active } = body;

    if (!id) {
      return NextResponse.json(
        { error: "Missing required field: id" },
        { status: 400 },
      );
    }

    // Update ad block
    const updateData: any = {
      updated_at: new Date().toISOString(),
    };

    // Only include fields that are provided
    if (location !== undefined) updateData.location = location;
    if (html_code !== undefined) updateData.html_code = html_code;
    if (active !== undefined) updateData.active = active;

    const { data, error } = await supabase
      .from("ad_blocks")
      .update(updateData)
      .eq("id", id)
      .select();

    if (error) {
      console.error("Error updating ad block:", error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ adBlock: data[0] });
  } catch (error: any) {
    console.error("Error in PUT ad block:", error);
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: 500 },
    );
  }
}

// DELETE ad block
export async function DELETE(request: NextRequest) {
  try {
    const supabase = await createClient();

    // Check if user is admin
    if (!(await isAdmin(supabase))) {
      return NextResponse.json(
        { error: "Unauthorized: Admin access required" },
        { status: 403 },
      );
    }

    // Get ad block ID from URL
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        { error: "Missing required field: id" },
        { status: 400 },
      );
    }

    // Delete ad block
    const { error } = await supabase.from("ad_blocks").delete().eq("id", id);

    if (error) {
      console.error("Error deleting ad block:", error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error("Error in DELETE ad block:", error);
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: 500 },
    );
  }
}
