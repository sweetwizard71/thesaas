import { NextRequest, NextResponse } from "next/server";
import { createClient } from "../../../../../supabase/server";

// Helper function to check if user is admin
async function isAdmin(supabase: any) {
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return false;
  }

  // Get user profile from the database to check admin status
  const { data: userProfile } = await supabase
    .from("users")
    .select("is_admin")
    .eq("id", user.id)
    .single();

  return userProfile?.is_admin === true;
}

// GET all models
export async function GET() {
  try {
    const supabase = await createClient();

    // Check authentication
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get all models
    const { data: models, error } = await supabase
      .from("ai_models")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error fetching models:", error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ models });
  } catch (error: any) {
    console.error("Error in GET models:", error);
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: 500 },
    );
  }
}

// POST new model
export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient();

    // Check if user is admin
    if (!(await isAdmin(supabase))) {
      return NextResponse.json(
        { error: "Unauthorized: Admin access required" },
        { status: 403 },
      );
    }

    // Get request body
    const body = await request.json();
    const { id, name, description, type, version } = body;

    if (!id || !name) {
      return NextResponse.json(
        { error: "Missing required fields: id and name are required" },
        { status: 400 },
      );
    }

    // Set default values for optional fields
    const modelType = type || "chat";
    const modelVersion = version || "1.0";

    // Insert new model with ad settings
    const { data, error } = await supabase
      .from("ai_models")
      .insert([
        {
          id,
          name,
          description,
          type: modelType,
          version: modelVersion,

          is_active: true,
        },
      ])
      .select();

    if (error) {
      console.error("Error creating model:", error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ model: data[0] });
  } catch (error: any) {
    console.error("Error in POST model:", error);
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: 500 },
    );
  }
}

// PUT update model
export async function PUT(request: NextRequest) {
  try {
    const supabase = await createClient();

    // Check if user is admin
    if (!(await isAdmin(supabase))) {
      return NextResponse.json(
        { error: "Unauthorized: Admin access required" },
        { status: 403 },
      );
    }

    // Get request body
    const body = await request.json();
    const { id, name, description, type, version, is_active } = body;

    if (!id) {
      return NextResponse.json({ error: "Missing model ID" }, { status: 400 });
    }

    // Update model (including ad settings if provided)
    const { ad_code, ad_frequency, ad_enabled } = body;

    // Check if the model exists first
    const { data: existingModel, error: checkError } = await supabase
      .from("ai_models")
      .select("id")
      .eq("id", id)
      .single();

    if (checkError && checkError.code === "PGRST116") {
      // Model doesn't exist, create it (for ad blocks that might not be in DB yet)
      const { data: insertData, error: insertError } = await supabase
        .from("ai_models")
        .insert([
          {
            id,
            name: name || id,
            description: description || `Ad placement for ${name || id}`,
            type: type || "page",
            version: version || "1.0",
            is_active: is_active !== undefined ? is_active : true,
            ad_code,

            ad_frequency,
            ad_enabled,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          },
        ])
        .select();

      if (insertError) {
        console.error("Error creating model:", insertError);
        return NextResponse.json(
          { error: insertError.message },
          { status: 500 },
        );
      }

      return NextResponse.json({ model: insertData[0] });
    } else {
      // Model exists, update it
      const updateData: any = {
        updated_at: new Date().toISOString(),
      };

      // Only include fields that are provided
      if (name !== undefined) updateData.name = name;
      if (description !== undefined) updateData.description = description;
      if (type !== undefined) updateData.type = type;
      if (version !== undefined) updateData.version = version;
      if (is_active !== undefined) updateData.is_active = is_active;
      if (ad_code !== undefined) updateData.ad_code = ad_code;

      if (ad_frequency !== undefined) updateData.ad_frequency = ad_frequency;
      if (ad_enabled !== undefined) updateData.ad_enabled = Boolean(ad_enabled);

      const { data, error } = await supabase
        .from("ai_models")
        .update(updateData)
        .eq("id", id)
        .select();

      if (error) {
        console.error("Error updating model:", error);
        return NextResponse.json({ error: error.message }, { status: 500 });
      }

      return NextResponse.json({ model: data[0] });
    }
  } catch (error: any) {
    console.error("Error in PUT model:", error);
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: 500 },
    );
  }
}

// DELETE model
export async function DELETE(request: NextRequest) {
  try {
    const supabase = await createClient();

    // Check if user is admin
    if (!(await isAdmin(supabase))) {
      return NextResponse.json(
        { error: "Unauthorized: Admin access required" },
        { status: 403 },
      );
    }

    // Get model ID from URL
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "Missing model ID" }, { status: 400 });
    }

    // Delete model (or set as inactive)
    const { error } = await supabase
      .from("ai_models")
      .update({ is_active: false })
      .eq("id", id);

    if (error) {
      console.error("Error deleting model:", error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error("Error in DELETE model:", error);
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: 500 },
    );
  }
}
