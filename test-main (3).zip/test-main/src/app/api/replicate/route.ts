import { NextRequest, NextResponse } from "next/server";
import { createClient } from "../../../../supabase/server";
import { chatModels, imageModels } from "@/lib/replicate";
import Replicate from "replicate";

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient();

    // Check authentication
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Initialize Replicate client with fallback mock implementation
    let replicate;
    const apiKey =
      process.env.REPLICATE_API_KEY || process.env.REPLICATE_API_TOKEN;

    if (apiKey && apiKey !== "r8_") {
      replicate = new Replicate({
        auth: apiKey,
      });
    } else {
      // Mock implementation when no valid API key is available
      replicate = {
        run: async (model: string, options: any) => {
          // Return mock data based on type
          if (model.includes("llama") || model.includes("mistral")) {
            return "This is a mock response from the AI model. To get real responses, please add a valid Replicate API key to your environment variables.";
          } else {
            // Return a placeholder image URL for image models
            return [
              "https://images.unsplash.com/photo-1682687982501-1e58ab814714?w=800&q=80",
            ];
          }
        },
      };
    }

    // Get request body
    const body = await request.json();
    const {
      type,
      prompt,
      modelId,
      temperature = 0.7,
      resolution = "1024x1024",
      history = [],
      imagePrompt = null,
    } = body;

    if (!type || !prompt || !modelId) {
      return NextResponse.json(
        { error: "Missing required parameters" },
        { status: 400 },
      );
    }

    // Find the model version based on the modelId
    let modelVersion = "";
    if (type === "chat") {
      const model = chatModels.find((m) => m.id === modelId);
      if (!model) {
        return NextResponse.json(
          { error: `Chat model ${modelId} not found` },
          { status: 400 },
        );
      }
      modelVersion = model.version;

      if (!modelVersion) {
        return NextResponse.json(
          { error: `Invalid model version format for ${modelId}` },
          { status: 400 },
        );
      }
    } else if (type === "image") {
      const model = imageModels.find((m) => m.id === modelId);
      if (!model) {
        return NextResponse.json(
          { error: `Image model ${modelId} not found` },
          { status: 400 },
        );
      }
      modelVersion = model.version;

      if (!modelVersion) {
        return NextResponse.json(
          { error: `Invalid model version format for ${modelId}` },
          { status: 400 },
        );
      }
    } else {
      return NextResponse.json(
        { error: "Invalid type. Must be 'chat' or 'image'" },
        { status: 400 },
      );
    }

    try {
      if (type === "chat") {
        return await handleChatRequest(
          apiKey,
          modelId,
          modelVersion,
          prompt,
          temperature,
          replicate,
          history,
        );
      } else if (type === "image") {
        return await handleImageRequest(
          apiKey,
          modelId,
          modelVersion,
          prompt,
          resolution,
          replicate,
          imagePrompt,
        );
      }
    } catch (apiError: any) {
      return NextResponse.json(
        { error: apiError.message || "Error calling Replicate API" },
        { status: 500 },
      );
    }
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: 500 },
    );
  }
}

async function handleChatRequest(
  apiKey: string,
  modelId: string,
  modelVersion: string,
  prompt: string,
  temperature: number,
  replicate: any,
  history: Array<{ role: string; content: string }> = [],
) {
  // Configure input based on the model
  let input = {};

  if (modelId.includes("llama")) {
    // Format conversation history for Llama models
    let formattedPrompt = prompt;
    if (history.length > 0) {
      const conversationHistory = history
        .map(
          (msg) =>
            `${msg.role === "user" ? "Human" : "Assistant"}: ${msg.content}`,
        )
        .join("\n");
      formattedPrompt = `${conversationHistory}\nHuman: ${prompt}\nAssistant:`;
    }

    input = {
      prompt: formattedPrompt,
      temperature: parseFloat(temperature.toString()),
      max_tokens: 500,
      system_prompt: "You are a helpful AI assistant.",
    };
  } else if (modelId.includes("mistral")) {
    // Format conversation history for Mistral models
    let formattedPrompt = prompt;
    if (history.length > 0) {
      const conversationHistory = history
        .map((msg) => {
          if (msg.role === "user") {
            return `<s>[INST] ${msg.content} [/INST]`;
          } else {
            return msg.content;
          }
        })
        .join("");
      formattedPrompt = `${conversationHistory}<s>[INST] ${prompt} [/INST]`;
    } else {
      formattedPrompt = `<s>[INST] ${prompt} [/INST]`;
    }

    input = {
      prompt: formattedPrompt,
      temperature: parseFloat(temperature.toString()),
      max_tokens: 500,
    };
  } else if (modelId.includes("claude")) {
    // Format conversation history for Claude models
    let formattedPrompt = prompt;
    if (history.length > 0) {
      const conversationHistory = history
        .map(
          (msg) =>
            `${msg.role === "user" ? "Human" : "Assistant"}: ${msg.content}`,
        )
        .join("\n\n");
      formattedPrompt = `${conversationHistory}\n\nHuman: ${prompt}\n\nAssistant:`;
    }

    input = {
      prompt: formattedPrompt,
      temperature: parseFloat(temperature.toString()),
      max_tokens: 8192,
      system_prompt: "You are a helpful AI assistant.",
      max_image_resolution: 0.5,
    };
  } else {
    // Default format for other models
    let formattedPrompt = prompt;
    if (history.length > 0) {
      const conversationHistory = history
        .map((msg) => `${msg.role === "user" ? "User" : "AI"}: ${msg.content}`)
        .join("\n");
      formattedPrompt = `${conversationHistory}\nUser: ${prompt}\nAI:`;
    }

    input = {
      prompt: formattedPrompt,
      temperature: parseFloat(temperature.toString()),
      max_tokens: 500,
    };
  }

  try {
    let output;

    if (apiKey && apiKey !== "r8_") {
      // Use direct API call for chat models
      const createResponse = await fetch(
        "https://api.replicate.com/v1/predictions",
        {
          method: "POST",
          headers: {
            Authorization: `Token ${apiKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            version: modelVersion,
            input: input,
          }),
        },
      );

      if (!createResponse.ok) {
        throw new Error(`Replicate API error: ${createResponse.status}`);
      }

      const prediction = await createResponse.json();
      const predictionId = prediction.id;

      // Poll for results
      let result;
      let attempts = 0;
      const maxAttempts = 120;

      while (attempts < maxAttempts) {
        attempts++;

        const pollResponse = await fetch(
          `https://api.replicate.com/v1/predictions/${predictionId}`,
          {
            headers: {
              Authorization: `Token ${apiKey}`,
            },
          },
        );

        if (!pollResponse.ok) {
          throw new Error(`Polling error: ${pollResponse.status}`);
        }

        result = await pollResponse.json();

        if (result.status === "succeeded") {
          output = result.output;
          break;
        } else if (result.status === "failed") {
          throw new Error(
            "Prediction failed: " + (result.error || "Unknown error"),
          );
        }

        // Wait before polling again (using exponential backoff)
        const backoffTime = Math.min(
          2000 * Math.pow(1.5, Math.floor(attempts / 10)),
          10000,
        );
        await new Promise((resolve) => setTimeout(resolve, backoffTime));
      }

      if (attempts >= maxAttempts) {
        throw new Error("Prediction timed out after maximum polling attempts");
      }
    } else {
      // Fallback to using the replicate.run method
      output = await replicate.run(`${modelId}:${modelVersion}`, {
        input: input,
      });
    }

    // Process chat output - typically a string or array of strings
    const response = Array.isArray(output) ? output.join("") : output;

    return NextResponse.json({
      response: response,
      model: modelId,
    });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Error running chat model" },
      { status: 500 },
    );
  }
}

async function handleImageRequest(
  apiKey: string,
  modelId: string,
  modelVersion: string,
  prompt: string,
  resolution: string,
  replicate: any,
  imagePrompt: string | null = null,
) {
  // Parse resolution
  const [width, height] = resolution.split("x").map(Number);

  // Configure input based on the model
  const input: any = {
    prompt: prompt,
    width: width,
    height: height,
    num_outputs: 1,
  };

  // Add image prompt if provided
  if (imagePrompt) {
    // If it's a base64 string, use it directly
    if (imagePrompt.startsWith("data:image")) {
      input.image_prompt = imagePrompt;
    } else {
      // Otherwise assume it's a URL
      input.image_prompt = imagePrompt;
    }
  }

  try {
    let output;

    if (apiKey && apiKey !== "r8_") {
      // Direct API call to Replicate
      const createResponse = await fetch(
        "https://api.replicate.com/v1/predictions",
        {
          method: "POST",
          headers: {
            Authorization: `Token ${apiKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            version: modelVersion,
            input: input,
          }),
        },
      );

      if (!createResponse.ok) {
        throw new Error(`Replicate API error: ${createResponse.status}`);
      }

      const prediction = await createResponse.json();
      const predictionId = prediction.id;

      // Poll for results
      let result;
      let attempts = 0;
      const maxAttempts = 120;

      while (attempts < maxAttempts) {
        attempts++;

        const pollResponse = await fetch(
          `https://api.replicate.com/v1/predictions/${predictionId}`,
          {
            headers: {
              Authorization: `Token ${apiKey}`,
            },
          },
        );

        if (!pollResponse.ok) {
          throw new Error(`Polling error: ${pollResponse.status}`);
        }

        result = await pollResponse.json();

        if (result.status === "succeeded") {
          output = result.output;
          break;
        } else if (result.status === "failed") {
          throw new Error(
            "Prediction failed: " + (result.error || "Unknown error"),
          );
        }

        // Wait before polling again (using exponential backoff)
        const backoffTime = Math.min(
          2000 * Math.pow(1.5, Math.floor(attempts / 10)),
          10000,
        );
        await new Promise((resolve) => setTimeout(resolve, backoffTime));
      }

      if (attempts >= maxAttempts) {
        throw new Error("Prediction timed out after maximum polling attempts");
      }
    } else {
      // Use the existing replicate.run method
      output = await replicate.run(`${modelId}:${modelVersion}`, {
        input: input,
      });
    }

    // Extract image URL from output
    let imageUrl = extractImageUrl(output);

    return NextResponse.json({
      imageUrl: imageUrl,
      model: modelId,
      originalUrl: imageUrl,
      success: true,
    });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Error generating image" },
      { status: 500 },
    );
  }
}

function extractImageUrl(output: any): string {
  let imageUrl = null;

  // Try all possible formats to extract the URL
  if (Array.isArray(output)) {
    // Most common format: array of URLs
    imageUrl = output[0];
  } else if (typeof output === "string") {
    // Single URL string
    imageUrl = output;
  } else if (output && typeof output === "object") {
    // Object with output property (common in newer models)
    if (output.output) {
      if (Array.isArray(output.output) && output.output.length > 0) {
        imageUrl = output.output[0];
      } else if (typeof output.output === "string") {
        imageUrl = output.output;
      }
    } else if (output.images) {
      if (Array.isArray(output.images) && output.images.length > 0) {
        imageUrl = output.images[0];
      } else if (typeof output.images === "string") {
        imageUrl = output.images;
      }
    } else if (output.url) {
      imageUrl = output.url;
    } else if (output.image) {
      imageUrl = output.image;
    } else {
      // Try to find any property that might contain a URL
      for (const key in output) {
        if (
          typeof output[key] === "string" &&
          (output[key].startsWith("http") ||
            output[key].includes("replicate") ||
            output[key].includes("amazonaws"))
        ) {
          imageUrl = output[key];
          break;
        } else if (
          Array.isArray(output[key]) &&
          output[key].length > 0 &&
          typeof output[key][0] === "string" &&
          (output[key][0].startsWith("http") ||
            output[key][0].includes("replicate") ||
            output[key][0].includes("amazonaws"))
        ) {
          imageUrl = output[key][0];
          break;
        }
      }
    }
  }

  // Fallback to a placeholder image if we can't extract a URL
  if (
    !imageUrl ||
    typeof imageUrl !== "string" ||
    !imageUrl.startsWith("http")
  ) {
    imageUrl =
      "https://images.unsplash.com/photo-1682687982501-1e58ab814714?w=800&q=80";
  }

  return imageUrl;
}
