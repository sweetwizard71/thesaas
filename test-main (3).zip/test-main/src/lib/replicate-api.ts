/**
 * Replicate API client for making direct API calls
 */

const REPLICATE_API_KEY = process.env.REPLICATE_API_KEY;

interface ReplicatePredictionResponse {
  id: string;
  version: string;
  urls: {
    get: string;
    cancel: string;
  };
  status: string;
  created_at: string;
  completed_at?: string;
  output?: string[] | null;
  error?: string | null;
}

export async function runReplicateModel(
  modelId: string,
  modelVersion: string,
  input: Record<string, any>,
): Promise<ReplicatePredictionResponse> {
  const response = await fetch("https://api.replicate.com/v1/predictions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Token ${REPLICATE_API_KEY}`,
    },
    body: JSON.stringify({
      version: modelVersion,
      input: input,
    }),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(
      `Replicate API error: ${error.detail || JSON.stringify(error)}`,
    );
  }

  return await response.json();
}

export async function getPredictionResult(
  url: string,
): Promise<ReplicatePredictionResponse> {
  const response = await fetch(url, {
    headers: {
      Authorization: `Token ${REPLICATE_API_KEY}`,
      "Content-Type": "application/json",
    },
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(
      `Replicate API error: ${error.detail || JSON.stringify(error)}`,
    );
  }

  return await response.json();
}

export async function waitForPredictionResult(
  prediction: ReplicatePredictionResponse,
): Promise<any> {
  let result = prediction;

  // Poll until the prediction is complete
  while (result.status !== "succeeded" && result.status !== "failed") {
    await new Promise((resolve) => setTimeout(resolve, 1000)); // Wait 1 second
    result = await getPredictionResult(result.urls.get);
  }

  if (result.status === "failed") {
    throw new Error(`Prediction failed: ${result.error}`);
  }

  return result.output;
}
