/**
 * Replicate API client for chat and image generation
 */
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";

export type ChatModel = {
  id: string;
  name: string;
  description: string;
  version: string;
};

export type ImageModel = {
  id: string;
  name: string;
  description: string;
  version: string;
};

// Default chat models (fallback if database fetch fails)
const defaultChatModels: ChatModel[] = [
  {
    id: "meta/llama-2-70b-chat",
    name: "Llama 2 (70B)",
    description: "Meta's Llama 2 70B parameter chat model",
    version: "02e509c789964a7ea8736978a43525956ef40397be9033abf9fd2badfe68c9e3",
  },
  {
    id: "mistralai/mistral-7b-instruct-v0.1",
    name: "Mistral 7B",
    description: "Mistral AI's 7B parameter model",
    version: "83b6a56e7c828e667f21fd596c338fd4f0039b46bcfa18d973e8e70e455fda70",
  },
  {
    id: "a16z-infra/llama-2-13b-chat",
    name: "Llama 2 (13B)",
    description: "Llama 2 13B chat model",
    version: "78e26f857daa5eb1c82f5b4a2a6755cc18962f04be31f9890fb8146a772dc1e5",
  },
  {
    id: "anthropic/claude-3.7-sonnet",
    name: "Claude 3.7 Sonnet",
    description: "Anthropic's Claude 3.7 Sonnet model",
    version: "8a35a9d8f7aa324c86233f9ff2c1be9e147ed8e1e9f8f3c988e8cc5e568f3d40",
  },
];

// Default image models (fallback if database fetch fails)
const defaultImageModels: ImageModel[] = [
  {
    id: "stability-ai/sdxl",
    name: "Stable Diffusion XL",
    description: "Stability AI's SDXL model for high-quality image generation",
    version: "39ed52f2a78e934b3ba6e2a89f5b1c712de7dfea535525255b1aa35c5565e08b",
  },
  {
    id: "stability-ai/stable-diffusion",
    name: "Stable Diffusion 2",
    description: "Stability AI's Stable Diffusion model",
    version: "db21e45d3f7023abc2a46ee38a23973f6dce16bb082a930b0c49861f96d1e5bf",
  },
  {
    id: "prompthero/openjourney",
    name: "OpenJourney",
    description: "Midjourney-like image generation model",
    version: "9936c2001faa2194a261c01381f90e65261879985476014a0a37a334593a05eb",
  },
];

// Cached models to avoid excessive fetching
let cachedChatModels: ChatModel[] | null = null;
let cachedImageModels: ImageModel[] | null = null;
let lastFetchTime = 0;
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

// Fetch models from the database
async function fetchModelsFromDB() {
  try {
    const supabase = createClientComponentClient();

    // Only fetch if cache is expired
    const now = Date.now();
    if (
      cachedChatModels &&
      cachedImageModels &&
      now - lastFetchTime < CACHE_DURATION
    ) {
      return { chatModels: cachedChatModels, imageModels: cachedImageModels };
    }

    const { data: models, error } = await supabase
      .from("ai_models")
      .select("*")
      .eq("is_active", true);

    if (error) {
      console.error("Error fetching models:", error);
      return {
        chatModels: cachedChatModels || defaultChatModels,
        imageModels: cachedImageModels || defaultImageModels,
      };
    }

    // Process models by type
    const chatModels = models
      .filter((model) => model.type === "chat")
      .map((model) => ({
        id: model.id,
        name: model.name,
        description: model.description || "",
        version: model.version,
      }));

    const imageModels = models
      .filter((model) => model.type === "image")
      .map((model) => ({
        id: model.id,
        name: model.name,
        description: model.description || "",
        version: model.version,
      }));

    // Update cache
    cachedChatModels = chatModels.length > 0 ? chatModels : defaultChatModels;
    cachedImageModels =
      imageModels.length > 0 ? imageModels : defaultImageModels;
    lastFetchTime = now;

    return { chatModels: cachedChatModels, imageModels: cachedImageModels };
  } catch (error) {
    console.error("Error in fetchModelsFromDB:", error);
    return {
      chatModels: cachedChatModels || defaultChatModels,
      imageModels: cachedImageModels || defaultImageModels,
    };
  }
}

// Exported models - these will be fetched from the database
export let chatModels: ChatModel[] = [...defaultChatModels];
export let imageModels: ImageModel[] = [...defaultImageModels];

// Initialize models
fetchModelsFromDB().then(({ chatModels: cm, imageModels: im }) => {
  chatModels = cm;
  imageModels = im;
});

// Function to refresh models from the database
export async function refreshModels() {
  const { chatModels: cm, imageModels: im } = await fetchModelsFromDB();
  chatModels = cm;
  imageModels = im;
  return { chatModels, imageModels };
}

/**
 * Generate a chat response using Replicate API
 */
export async function generateChatResponse(
  prompt: string,
  modelId: string,
  modelVersion: string,
) {
  // This is a placeholder for the actual API implementation
  // In a real implementation, you would make a fetch request to Replicate API
  console.log(`Generating chat response with model ${modelId}:${modelVersion}`);

  // For now, return a mock response
  return {
    response: `This is a mock response to: "${prompt}". In a real implementation, this would come from the Replicate API using the ${modelId} model.`,
    model: modelId,
  };
}

/**
 * Generate an image using Replicate API
 */
export async function generateImage(
  prompt: string,
  modelId: string,
  modelVersion: string,
) {
  // This is a placeholder for the actual API implementation
  // In a real implementation, you would make a fetch request to Replicate API
  console.log(`Generating image with model ${modelId}:${modelVersion}`);

  // For now, return a mock response
  return {
    imageUrl:
      "https://images.unsplash.com/photo-1682687982501-1e58ab814714?w=800&q=80",
    model: modelId,
  };
}
