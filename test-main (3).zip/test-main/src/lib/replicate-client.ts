import Replicate from "replicate";

const replicate = new Replicate({
  auth:
    process.env.REPLICATE_API_TOKEN || process.env.REPLICATE_API_KEY || "r8_",
});

export default replicate;
